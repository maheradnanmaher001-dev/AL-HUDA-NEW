"""
Forces compileSdk/targetSdk to a fixed version across:
  1. our own android/app module, and
  2. every downloaded Flutter plugin's own Android build file
     (e.g. geocoding_android, geolocator_android, shared_preferences_android)

This matters because each plugin ships its OWN android/build.gradle with its
own compileSdk setting — overriding only the app module (or only
local.properties) does not change what those plugin subprojects compile
against, which is what was causing repeated
":<plugin>:checkDebugAarMetadata" build failures.
"""
import re
import glob
import os

TARGET = "36"

PATTERNS = [
    (re.compile(r'compileSdk\s*=\s*flutter\.compileSdkVersion'), f'compileSdk = {TARGET}'),
    (re.compile(r'compileSdk\s*=\s*\d+'), f'compileSdk = {TARGET}'),
    (re.compile(r'compileSdkVersion\s+flutter\.compileSdkVersion'), f'compileSdkVersion {TARGET}'),
    (re.compile(r'compileSdkVersion\s+\d+'), f'compileSdkVersion {TARGET}'),
    (re.compile(r'targetSdk\s*=\s*flutter\.targetSdkVersion'), f'targetSdk = {TARGET}'),
    (re.compile(r'targetSdk\s*=\s*\d+'), f'targetSdk = {TARGET}'),
    (re.compile(r'targetSdkVersion\s+flutter\.targetSdkVersion'), f'targetSdkVersion {TARGET}'),
    (re.compile(r'targetSdkVersion\s+\d+'), f'targetSdkVersion {TARGET}'),
]


def patch(path, changed_files):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception:
        return
    original = content
    for pattern, replacement in PATTERNS:
        content = pattern.sub(replacement, content)
    if content != original:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        changed_files.append(path)


def main():
    changed_files = []

    # 1) Our own app module.
    for p in ['android/app/build.gradle', 'android/app/build.gradle.kts']:
        if os.path.exists(p):
            patch(p, changed_files)

    # 2) Every Flutter plugin's own Android build file, wherever pub
    #    downloaded it.
    pub_cache = os.environ.get('PUB_CACHE', os.path.expanduser('~/.pub-cache'))
    search_roots = [pub_cache]
    flutter_root = os.environ.get('FLUTTER_ROOT')
    if flutter_root:
        search_roots.append(os.path.join(flutter_root, '.pub-cache'))

    for root_dir in search_roots:
        for pattern in ('build.gradle', 'build.gradle.kts'):
            for path in glob.glob(
                os.path.join(root_dir, '**', 'android', pattern), recursive=True
            ):
                patch(path, changed_files)

    print(f"Patched {len(changed_files)} build.gradle(.kts) file(s) to compileSdk/targetSdk {TARGET}:")
    for f in changed_files:
        print(f"  - {f}")

    if not changed_files:
        print("WARNING: no files were patched — nothing matched the expected patterns.")

    # 3) Fail-safe: force compileSdk for EVERY Android subproject (app +
    #    every plugin) at the Gradle level. This does not depend on finding
    #    or regex-matching each plugin's build file individually, so a
    #    plugin that the glob above misses (wrong pub-cache layout, new
    #    plugin added later, different regex shape, etc.) can no longer
    #    cause a ":<plugin>:checkDebugAarMetadata" failure like the one
    #    seen with geocoding_android.
    marker = "// __compileSdk_force_patch__"
    root_kts = 'android/build.gradle.kts'
    root_groovy = 'android/build.gradle'

    # IMPORTANT: this block must be PREPENDED (placed before everything
    # else in the file), not appended at the end. Flutter's default
    # template contains a later line — `subprojects { project.
    # evaluationDependsOn(":app") }` — which forces the ":app" project to
    # evaluate immediately, right there in the file. If our
    # `afterEvaluate` registration comes AFTER that line (e.g. appended at
    # the end of the file), ":app" is already evaluated by the time our
    # code runs, and Gradle throws:
    #   "Cannot run Project.afterEvaluate(Action) when the project is
    #    already evaluated."
    # Registering our afterEvaluate callback before that line runs avoids
    # this entirely — the callback is simply queued and fires safely
    # later, whenever each subproject (including :app) actually evaluates.
    if os.path.exists(root_kts):
        with open(root_kts, 'r', encoding='utf-8') as f:
            content = f.read()
        if marker not in content:
            block = f'''{marker}
subprojects {{
    afterEvaluate {{
        extensions.findByName("android")?.let {{ ext ->
            (ext as com.android.build.gradle.BaseExtension).apply {{
                compileSdkVersion({TARGET})
            }}
        }}
    }}
}}

'''
            with open(root_kts, 'w', encoding='utf-8') as f:
                f.write(block + content)
            print(f"Prepended subprojects-wide compileSdk={TARGET} fail-safe to {root_kts}")
        else:
            print(f"Fail-safe already present in {root_kts}, skipping.")
    elif os.path.exists(root_groovy):
        with open(root_groovy, 'r', encoding='utf-8') as f:
            content = f.read()
        if marker not in content:
            block = f'''{marker}
subprojects {{
    afterEvaluate {{ project ->
        if (project.hasProperty("android")) {{
            project.android {{
                compileSdkVersion {TARGET}
            }}
        }}
    }}
}}

'''
            with open(root_groovy, 'w', encoding='utf-8') as f:
                f.write(block + content)
            print(f"Prepended subprojects-wide compileSdk={TARGET} fail-safe to {root_groovy}")
        else:
            print(f"Fail-safe already present in {root_groovy}, skipping.")
    else:
        print("WARNING: root android/build.gradle(.kts) not found — could not add subprojects fail-safe.")


if __name__ == '__main__':
    main()
