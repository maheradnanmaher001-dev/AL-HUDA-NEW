import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String _kQuranApiBase = 'https://api.alquran.cloud/v1';

class SurahInfo {
  final int number;
  final String nameArabic;
  final String nameEnglish;
  final String nameTranslation;
  final int ayahCount;
  final String revelationType;

  SurahInfo({
    required this.number,
    required this.nameArabic,
    required this.nameEnglish,
    required this.nameTranslation,
    required this.ayahCount,
    required this.revelationType,
  });

  factory SurahInfo.fromJson(Map<String, dynamic> j) => SurahInfo(
        number: j['number'],
        nameArabic: j['name'],
        nameEnglish: j['englishName'],
        nameTranslation: j['englishNameTranslation'],
        ayahCount: j['numberOfAyahs'],
        revelationType: j['revelationType'],
      );
}

class Ayah {
  final int numberInSurah;
  final String arabic;
  final String urdu;
  final String english;

  Ayah({
    required this.numberInSurah,
    required this.arabic,
    required this.urdu,
    required this.english,
  });
}

class QuranService {
  static const _surahCacheKey = 'quran_surah_list_cache_v1';
  static const _lastSurahKey = 'quran_last_surah_number';
  static const _lastSurahScrollKey = 'quran_last_surah_scroll';
  static const _lastJuzKey = 'quran_last_juz_number';
  static const _lastJuzScrollKey = 'quran_last_juz_scroll';

  Future<List<SurahInfo>> fetchSurahList() async {
    final prefs = await SharedPreferences.getInstance();
    try {
      final res = await http
          .get(Uri.parse('$_kQuranApiBase/surah'))
          .timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final list = (body['data'] as List)
            .map((e) => SurahInfo.fromJson(e as Map<String, dynamic>))
            .toList();
        await prefs.setString(_surahCacheKey, res.body);
        return list;
      }
    } catch (_) {
      // fall through to cache
    }
    final cached = prefs.getString(_surahCacheKey);
    if (cached != null) {
      final body = jsonDecode(cached);
      return (body['data'] as List)
          .map((e) => SurahInfo.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    throw 'Could not load the Surah list. Check your internet connection.';
  }

  /// Fetches one Surah with Arabic text + Urdu and English translations, merged
  /// ayah-by-ayah.
  Future<List<Ayah>> fetchSurah(int number) async {
    final res = await http
        .get(Uri.parse('$_kQuranApiBase/surah/$number/editions/quran-simple,ur.jalandhry,en.sahih'))
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw 'Could not load this Surah. Check your internet connection.';
    }
    final body = jsonDecode(res.body);
    final editions = body['data'] as List; // [arabic, urdu, english]
    final arabicAyahs = editions[0]['ayahs'] as List;
    final urduAyahs = editions[1]['ayahs'] as List;
    final englishAyahs = editions[2]['ayahs'] as List;
    final result = <Ayah>[];
    for (var i = 0; i < arabicAyahs.length; i++) {
      result.add(Ayah(
        numberInSurah: arabicAyahs[i]['numberInSurah'],
        arabic: arabicAyahs[i]['text'],
        urdu: urduAyahs[i]['text'],
        english: englishAyahs[i]['text'],
      ));
    }
    return result;
  }

  /// Fetches one Juz (1-30) with Arabic text + Urdu and English translations.
  Future<List<Ayah>> fetchJuz(int number) async {
    final res = await http
        .get(Uri.parse('$_kQuranApiBase/juz/$number/editions/quran-simple,ur.jalandhry,en.sahih'))
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) {
      throw 'Could not load this Juz. Check your internet connection.';
    }
    final body = jsonDecode(res.body);
    final editions = body['data'] as List;
    final arabicAyahs = editions[0]['ayahs'] as List;
    final urduAyahs = editions[1]['ayahs'] as List;
    final englishAyahs = editions[2]['ayahs'] as List;
    final result = <Ayah>[];
    for (var i = 0; i < arabicAyahs.length; i++) {
      result.add(Ayah(
        numberInSurah: arabicAyahs[i]['numberInSurah'],
        arabic: arabicAyahs[i]['text'],
        urdu: urduAyahs[i]['text'],
        english: englishAyahs[i]['text'],
      ));
    }
    return result;
  }

  // ---- Resume position (kept separate for Surah view vs Juz view) ----

  Future<void> saveSurahProgress(int surahNumber, double scrollOffset) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_lastSurahKey, surahNumber);
    await prefs.setDouble(_lastSurahScrollKey, scrollOffset);
  }

  Future<(int, double)?> loadSurahProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final n = prefs.getInt(_lastSurahKey);
    if (n == null) return null;
    return (n, prefs.getDouble(_lastSurahScrollKey) ?? 0.0);
  }

  Future<void> saveJuzProgress(int juzNumber, double scrollOffset) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_lastJuzKey, juzNumber);
    await prefs.setDouble(_lastJuzScrollKey, scrollOffset);
  }

  Future<(int, double)?> loadJuzProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final n = prefs.getInt(_lastJuzKey);
    if (n == null) return null;
    return (n, prefs.getDouble(_lastJuzScrollKey) ?? 0.0);
  }
}
