import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class DetectedLocation {
  final String city;
  final String country;
  DetectedLocation({required this.city, required this.country});

  String get display => '$city, $country';
}

class LocationService {
  /// Requests permission, gets the device's current GPS position, and
  /// reverse-geocodes it down to district/city level.
  /// Throws a plain [String] message on failure so the UI can show it
  /// and fall back to manual entry.
  Future<DetectedLocation> detectLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      throw 'Location services are turned off on this device.';
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      throw 'Location permission was denied.';
    }

    final position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.medium,
    );

    final placemarks = await placemarkFromCoordinates(
      position.latitude,
      position.longitude,
    );
    if (placemarks.isEmpty) {
      throw 'Could not determine your area from GPS.';
    }
    final p = placemarks.first;
    final city = (p.locality?.isNotEmpty == true)
        ? p.locality!
        : (p.subAdministrativeArea?.isNotEmpty == true)
            ? p.subAdministrativeArea!
            : (p.administrativeArea ?? '');
    final country = p.country ?? '';
    if (city.isEmpty || country.isEmpty) {
      throw 'Could not determine your area from GPS.';
    }
    return DetectedLocation(city: city, country: country);
  }
}
