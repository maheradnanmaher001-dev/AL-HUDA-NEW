import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app_state.dart';
import 'state/auth_state.dart';
import 'theme/app_theme.dart';
import 'screens/auth/auth_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appState = AppState();
  final authState = AuthState();
  await Future.wait([appState.load(), authState.load()]);
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appState),
        ChangeNotifierProvider.value(value: authState),
      ],
      child: const AlHudaApp(),
    ),
  );
}

class AlHudaApp extends StatelessWidget {
  const AlHudaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    return MaterialApp(
      title: 'AL-HUDA',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: appState.themeMode,
      builder: (context, child) {
        // Apply the user's chosen text size app-wide, on top of whatever
        // the device's own accessibility text scale is set to.
        final mq = MediaQuery.of(context);
        final combined = mq.textScaler.scale(1.0) * appState.textScale.factor;
        return MediaQuery(
          data: mq.copyWith(textScaler: TextScaler.linear(combined)),
          child: child!,
        );
      },
      home: const AuthGate(),
    );
  }
}
