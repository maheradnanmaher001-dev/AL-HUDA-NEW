import 'package:flutter/material.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';

enum ReaderMode { surah, juz }

class QuranReaderScreen extends StatefulWidget {
  final ReaderMode mode;
  final int number; // surah number (1-114) or juz number (1-30)
  final String title;

  const QuranReaderScreen({
    super.key,
    required this.mode,
    required this.number,
    required this.title,
  });

  @override
  State<QuranReaderScreen> createState() => _QuranReaderScreenState();
}

class _QuranReaderScreenState extends State<QuranReaderScreen> {
  final _service = QuranService();
  final _scrollController = ScrollController();
  List<Ayah>? _ayahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (widget.mode == ReaderMode.surah) {
      _service.saveSurahProgress(widget.number, _scrollController.offset);
    } else {
      _service.saveJuzProgress(widget.number, _scrollController.offset);
    }
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final ayahs = widget.mode == ReaderMode.surah
          ? await _service.fetchSurah(widget.number)
          : await _service.fetchJuz(widget.number);
      setState(() => _ayahs = ayahs);

      // Restore scroll position only if we're re-opening the exact same
      // surah/juz the user last left off on.
      final saved = widget.mode == ReaderMode.surah
          ? await _service.loadSurahProgress()
          : await _service.loadJuzProgress();
      if (saved != null && saved.$1 == widget.number && mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollController.hasClients) {
            _scrollController.jumpTo(saved.$2.clamp(
              0,
              _scrollController.position.maxScrollExtent,
            ));
          }
        });
      }
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ),
                ),
              )
            : _ayahs == null
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    controller: _scrollController,
                    padding: const EdgeInsets.all(16),
                    itemCount: _ayahs!.length,
                    separatorBuilder: (_, __) => const Divider(height: 28),
                    itemBuilder: (context, i) {
                      final a = _ayahs![i];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 12,
                                backgroundColor: AppColors.emerald,
                                child: Text(
                                  '${a.numberInSurah}',
                                  style: const TextStyle(fontSize: 10, color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            a.arabic,
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: const TextStyle(fontSize: 20, height: 1.9),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            a.urdu,
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: const TextStyle(fontSize: 15, height: 1.6, color: Color(0xFF3A453E)),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            a.english,
                            style: const TextStyle(fontSize: 13, color: Color(0xFF6B7A70)),
                          ),
                        ],
                      );
                    },
                  ),
      ),
    );
  }
}
