import 'package:flutter/material.dart';
import '../data/hadith_books.dart';
import '../theme/app_theme.dart';

class HadithScreen extends StatefulWidget {
  const HadithScreen({super.key});

  @override
  State<HadithScreen> createState() => _HadithScreenState();
}

class _HadithScreenState extends State<HadithScreen> {
  String _query = '';

  @override
  Widget build(BuildContext context) {
    final filtered = kHadithBooks
        .where((b) => b.nameEnglish.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hadith'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                onChanged: (v) => setState(() => _query = v),
                decoration: const InputDecoration(
                  hintText: 'Search Hadith books…',
                  prefixIcon: Icon(Icons.search),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Hadith text with narrator, grade and reference is coming in the next phase.',
                  style: TextStyle(fontSize: 11.5, color: Color(0xFF9AA39D)),
                ),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 4),
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, i) {
                  final b = filtered[i];
                  return ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: AppColors.emeraldSoft,
                      child: Icon(Icons.menu_book_outlined, color: AppColors.emerald, size: 18),
                    ),
                    title: Text(b.nameEnglish),
                    subtitle: Text('${b.compiler} · ~${b.approxHadithCount} Hadith'),
                    trailing: Text(
                      b.nameArabic,
                      style: const TextStyle(fontSize: 15),
                      textDirection: TextDirection.rtl,
                    ),
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('${b.nameEnglish} — coming soon')),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
