import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../app_state.dart';
import '../state/auth_state.dart';
import '../theme/app_theme.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(vertical: 8),
          children: [
            _SectionLabel('Prayer'),
            SwitchListTile(
              secondary: const Icon(Icons.alarm),
              title: const Text('Azan Alarm'),
              subtitle: const Text('Plays iqamah audio at prayer time (Phase 4)'),
              value: false,
              onChanged: null, // wired up in Phase 4
            ),
            const Divider(height: 24),
            _SectionLabel('Display'),
            SwitchListTile(
              secondary: const Icon(Icons.dark_mode_outlined),
              title: const Text('Dark Theme'),
              value: appState.themeMode == ThemeMode.dark,
              onChanged: (v) => appState.setDarkMode(v),
            ),
            ListTile(
              leading: const Icon(Icons.text_fields),
              title: const Text('Text Size'),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: SegmentedButton<AppTextScale>(
                  segments: const [
                    ButtonSegment(value: AppTextScale.small, label: Text('Small')),
                    ButtonSegment(value: AppTextScale.medium, label: Text('Medium')),
                    ButtonSegment(value: AppTextScale.large, label: Text('Large')),
                  ],
                  selected: {appState.textScale},
                  onSelectionChanged: (s) => appState.setTextScale(s.first),
                ),
              ),
            ),
            const Divider(height: 24),
            _SectionLabel('Account'),
            ListTile(
              leading: const Icon(Icons.person_outline),
              title: const Text('Account Information'),
              subtitle: Text(context.watch<AuthState>().email ?? 'Not signed in'),
            ),
            ListTile(
              leading: const Icon(Icons.location_on_outlined),
              title: const Text('Location'),
              subtitle: Text(context.watch<AuthState>().location ?? 'Not set'),
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Logout', style: TextStyle(color: Colors.red)),
              onTap: () => context.read<AuthState>().logout(),
            ),
            const Divider(height: 24),
            _SectionLabel('About'),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About AL-HUDA'),
              onTap: () => showDialog(
                context: context,
                builder: (_) => const _AboutDialog(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.1,
          color: AppColors.emerald,
        ),
      ),
    );
  }
}

class _AboutDialog extends StatelessWidget {
  const _AboutDialog();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('About AL-HUDA'),
      content: const Text(
        'AL-HUDA\n\n'
        'Created by: [Your Name Here]\n\n'
        'AL-HUDA is a licensed Islamic companion app providing the Quran, '
        'authentic Hadith, prayer times, Qibla direction, and daily duas '
        'to help users stay connected with their deen.\n\n'
        'Version 1.0.0',
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Close'),
        ),
      ],
    );
  }
}
