import 'package:flutter/material.dart';
import '../../services/auth_service.dart';
import '../../services/location_service.dart';
import 'auth_widgets.dart';
import 'verify_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  final _city = TextEditingController();
  final _country = TextEditingController();

  final _authService = AuthService();
  final _locationService = LocationService();

  bool _loading = false;
  bool _detectingLocation = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _detectLocation();
  }

  Future<void> _detectLocation() async {
    setState(() => _detectingLocation = true);
    try {
      final loc = await _locationService.detectLocation();
      _city.text = loc.city;
      _country.text = loc.country;
    } catch (_) {
      // Silently fall back to manual entry — the fields just stay empty.
    } finally {
      if (mounted) setState(() => _detectingLocation = false);
    }
  }

  Future<void> _submit() async {
    if (_password.text != _confirm.text) {
      setState(() => _error = 'Passwords do not match.');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      await _authService.register(
        email: _email.text.trim(),
        password: _password.text,
        city: _city.text.trim(),
        country: _country.text.trim(),
      );
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => VerifyScreen(email: _email.text.trim())),
      );
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthScaffold(
      title: 'Create account',
      subtitle: "We'll email you a verification code",
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AuthTextField(
            label: 'Email',
            controller: _email,
            keyboardType: TextInputType.emailAddress,
          ),
          AuthTextField(label: 'Password', controller: _password, obscure: true),
          AuthTextField(label: 'Confirm Password', controller: _confirm, obscure: true),
          Row(
            children: [
              Expanded(child: AuthTextField(label: 'City / District', controller: _city)),
              const SizedBox(width: 12),
              Expanded(child: AuthTextField(label: 'Country', controller: _country)),
            ],
          ),
          if (_detectingLocation)
            const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text('Detecting your location…',
                  style: TextStyle(color: Color(0xFF6B7A70), fontSize: 12)),
            ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(_error!, style: const TextStyle(color: Colors.red)),
            ),
          AuthPrimaryButton(label: 'Register', onPressed: _submit, loading: _loading),
        ],
      ),
    );
  }
}
