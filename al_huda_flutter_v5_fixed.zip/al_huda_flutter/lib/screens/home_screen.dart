import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // Custom header (Urdu title) instead of a plain English AppBar.
            SliverToBoxAdapter(
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 22),
                color: isDark ? AppColors.darkSurface : AppColors.emerald,
                child: Column(
                  children: [
                    Text(
                      'اَلْهُدَىٰ',
                      style: TextStyle(
                        fontSize: 30,
                        height: 1.3,
                        color: isDark ? AppColors.cream : Colors.white,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Sargodha, Pakistan',
                      style: TextStyle(
                        fontSize: 12,
                        color: (isDark ? AppColors.cream : Colors.white).withOpacity(0.75),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            // Faint mosque watermark sitting behind the content, on the cream area.
            SliverToBoxAdapter(
              child: Stack(
                children: [
                  Positioned(
                    top: -10,
                    left: -30,
                    right: -30,
                    child: Opacity(
                      opacity: 0.14,
                      child: Image.asset(
                        'assets/images/mosque_motif.png',
                        fit: BoxFit.fitWidth,
                        color: AppColors.emerald,
                        colorBlendMode: BlendMode.srcIn,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 32, 20, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Assalamu Alaikum',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Namaz times, daily zikr, dua and more will appear here.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
