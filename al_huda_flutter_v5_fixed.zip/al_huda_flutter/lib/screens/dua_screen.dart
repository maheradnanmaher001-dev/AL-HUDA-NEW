import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class DuaScreen extends StatelessWidget {
  const DuaScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dua')),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.favorite_border, size: 56, color: AppColors.emerald),
              const SizedBox(height: 12),
              const Text('Daily dua & full dua collection — coming in Phase 5'),
            ],
          ),
        ),
      ),
    );
  }
}
