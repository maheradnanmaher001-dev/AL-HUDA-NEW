import 'package:flutter/material.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';
import 'quran_reader_screen.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  final _service = QuranService();
  bool _showJuz = false;
  List<SurahInfo>? _surahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchSurahList();
      setState(() => _surahs = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _openSurah(SurahInfo s) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.surah,
        number: s.number,
        title: '${s.number}. ${s.nameEnglish}',
      ),
    ));
  }

  void _openJuz(int number) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.juz,
        number: number,
        title: 'Juz $number',
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quran'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Surah')),
                ButtonSegment(value: true, label: Text('Juz')),
              ],
              selected: {_showJuz},
              onSelectionChanged: (s) => setState(() => _showJuz = s.first),
            ),
          ),
        ),
      ),
      body: SafeArea(child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (_showJuz) {
      return ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 4),
        itemCount: 30,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final juz = i + 1;
          return ListTile(
            leading: CircleAvatar(
              backgroundColor: AppColors.emeraldSoft,
              child: Text('$juz', style: const TextStyle(color: AppColors.emerald, fontSize: 12)),
            ),
            title: Text('Juz $juz'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _openJuz(juz),
          );
        },
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _load, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    if (_surahs == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: _surahs!.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final s = _surahs![i];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: AppColors.emeraldSoft,
            child: Text('${s.number}', style: const TextStyle(color: AppColors.emerald, fontSize: 12)),
          ),
          title: Text(s.nameEnglish),
          subtitle: Text('${s.nameTranslation} · ${s.ayahCount} Ayahs · ${s.revelationType}'),
          trailing: Text(
            s.nameArabic,
            style: const TextStyle(fontSize: 18),
            textDirection: TextDirection.rtl,
          ),
          onTap: () => _openSurah(s),
        );
      },
    );
  }
}
