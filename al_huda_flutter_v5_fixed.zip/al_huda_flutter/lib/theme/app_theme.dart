import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// AL-HUDA color palette: matte dark emerald green + cream only (no gold).
class AppColors {
  // Matte dark emerald — flat, slightly desaturated so it doesn't look glossy.
  static const emerald = Color(0xFF0B4732);
  static const emeraldDeep = Color(0xFF073A28);
  static const emeraldSoft = Color(0xFFE7F0EA); // tint used for chip backgrounds
  static const cream = Color(0xFFFBF6EC);
  static const charcoal = Color(0xFF15201B);
  static const darkSurface = Color(0xFF102821);
}

enum AppTextScale { small, medium, large }

extension AppTextScaleValue on AppTextScale {
  double get factor {
    switch (this) {
      case AppTextScale.small:
        return 0.9;
      case AppTextScale.medium:
        return 1.0;
      case AppTextScale.large:
        return 1.2;
    }
  }
}

class AppTheme {
  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.cream,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.emerald,
        secondary: AppColors.emeraldDeep,
        surface: AppColors.cream,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.emerald,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.emerald,
        unselectedItemColor: Color(0xFF9AA39D),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.emerald,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme).apply(
      bodyColor: AppColors.cream,
      displayColor: AppColors.cream,
    );
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.charcoal,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.cream,
        secondary: AppColors.emeraldSoft,
        surface: AppColors.darkSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.darkSurface,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.darkSurface,
        selectedItemColor: AppColors.cream,
        unselectedItemColor: Color(0xFF7C8B83),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.emeraldSoft,
          foregroundColor: AppColors.emeraldDeep,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }
}
