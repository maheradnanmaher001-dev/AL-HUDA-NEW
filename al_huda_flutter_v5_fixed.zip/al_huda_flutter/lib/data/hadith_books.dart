class HadithBook {
  final String nameEnglish;
  final String nameArabic;
  final String compiler;
  final int approxHadithCount;

  const HadithBook({
    required this.nameEnglish,
    required this.nameArabic,
    required this.compiler,
    required this.approxHadithCount,
  });
}

/// The six major authentic Hadith collections (Kutub al-Sittah).
/// Hadith counts are commonly cited approximate figures.
const List<HadithBook> kHadithBooks = [
  HadithBook(nameEnglish: 'Sahih al-Bukhari', nameArabic: 'صحيح البخاري', compiler: 'Imam Muhammad al-Bukhari', approxHadithCount: 7563),
  HadithBook(nameEnglish: 'Sahih Muslim', nameArabic: 'صحيح مسلم', compiler: 'Imam Muslim ibn al-Hajjaj', approxHadithCount: 7500),
  HadithBook(nameEnglish: "Sunan Abu Dawud", nameArabic: 'سنن أبي داود', compiler: 'Imam Abu Dawud', approxHadithCount: 5274),
  HadithBook(nameEnglish: 'Jami at-Tirmidhi', nameArabic: 'جامع الترمذي', compiler: 'Imam at-Tirmidhi', approxHadithCount: 3956),
  HadithBook(nameEnglish: "Sunan an-Nasa'i", nameArabic: 'سنن النسائي', compiler: "Imam an-Nasa'i", approxHadithCount: 5758),
  HadithBook(nameEnglish: 'Sunan Ibn Majah', nameArabic: 'سنن ابن ماجه', compiler: 'Imam Ibn Majah', approxHadithCount: 4341),
];
