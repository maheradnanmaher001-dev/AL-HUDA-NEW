import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Tracks whether the user is logged in and holds their session token.
/// Persisted locally so the user stays logged in between app launches.
/// Note: a password reset only changes the password on the backend —
/// it does not touch anything stored locally, so bookmarks and settings
/// are untouched by a reset.
class AuthState extends ChangeNotifier {
  String? _token;
  String? _email;
  String? _location;

  bool get isLoggedIn => _token != null;
  String? get token => _token;
  String? get email => _email;
  String? get location => _location;

  static const _tokenKey = 'al_huda_auth_token';
  static const _emailKey = 'al_huda_auth_email';
  static const _locationKey = 'al_huda_auth_location';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(_tokenKey);
    _email = prefs.getString(_emailKey);
    _location = prefs.getString(_locationKey);
    notifyListeners();
  }

  Future<void> setSession({
    required String token,
    required String email,
    String? location,
  }) async {
    _token = token;
    _email = email;
    _location = location;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_emailKey, email);
    if (location != null) await prefs.setString(_locationKey, location);
  }

  Future<void> logout() async {
    _token = null;
    _email = null;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_emailKey);
  }
}
