import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'theme/app_theme.dart';

/// Holds app-wide settings (theme, text scale) and persists them locally
/// so they survive app restarts (and, later, account/password resets).
class AppState extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.light;
  AppTextScale _textScale = AppTextScale.medium;

  ThemeMode get themeMode => _themeMode;
  AppTextScale get textScale => _textScale;

  static const _themeKey = 'al_huda_theme_mode';
  static const _textScaleKey = 'al_huda_text_scale';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final theme = prefs.getString(_themeKey);
    if (theme == 'dark') _themeMode = ThemeMode.dark;
    final scale = prefs.getString(_textScaleKey);
    if (scale != null) {
      _textScale = AppTextScale.values.firstWhere(
        (e) => e.name == scale,
        orElse: () => AppTextScale.medium,
      );
    }
    notifyListeners();
  }

  Future<void> setDarkMode(bool isDark) async {
    _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_themeKey, isDark ? 'dark' : 'light');
  }

  Future<void> setTextScale(AppTextScale scale) async {
    _textScale = scale;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_textScaleKey, scale.name);
  }
}
