import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../data/juz_names.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';
import 'quran_reader_screen.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  final _service = QuranService();
  bool _showJuz = false;
  List<SurahInfo>? _surahs;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchSurahList();
      if (mounted) setState(() => _surahs = list);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  void _openSurah(SurahInfo s) => Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => QuranReaderScreen(mode: ReaderMode.surah, number: s.number, title: '${s.number}. ${s.nameEnglish}'),
  ));

  void _openJuz(int number) => Navigator.of(context).push(MaterialPageRoute(
    builder: (_) => QuranReaderScreen(mode: ReaderMode.juz, number: number, title: 'Para $number · ${kJuzNames[number - 1]}'),
  ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        title: Text('Quran', style: GoogleFonts.cormorantGaramond(fontSize: 25, fontWeight: FontWeight.w600)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(66),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 0, 22, 14),
            child: _SegmentedHeader(showJuz: _showJuz, onChanged: (v) => setState(() => _showJuz = v)),
          ),
        ),
      ),
      body: Stack(children: [
        Positioned.fill(child: Opacity(opacity: 0.07, child: Image.asset('assets/images/mosque_motif.png', fit: BoxFit.cover))),
        Positioned(top: -8, left: -45, right: -45, child: IgnorePointer(child: Opacity(opacity: 0.92, child: Image.asset('assets/images/hanging_lanterns.png', height: 150, fit: BoxFit.fitWidth)))),
        _buildBody(),
      ]),
    );
  }

  Widget _buildBody() {
    if (_showJuz) {
      return GridView.builder(
        padding: const EdgeInsets.fromLTRB(14, 118, 14, 20),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 10, childAspectRatio: .78),
        itemCount: 30,
        itemBuilder: (_, i) => _QuranTile(number: i + 1, arabic: kJuzNames[i], title: 'Para ${i + 1}', subtitle: 'Juz', onTap: () => _openJuz(i + 1)),
      );
    }
    if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 12), ElevatedButton(onPressed: _load, child: const Text('Retry'))]));
    if (_surahs == null) return const Center(child: CircularProgressIndicator());
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(14, 118, 14, 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 10, childAspectRatio: .78),
      itemCount: _surahs!.length,
      itemBuilder: (_, i) {
        final s = _surahs![i];
        return _QuranTile(number: s.number, arabic: s.nameArabic, title: s.nameEnglish, subtitle: '${s.ayahCount} Ayahs · ${s.revelationType}', onTap: () => _openSurah(s));
      },
    );
  }
}

class _SegmentedHeader extends StatelessWidget {
  final bool showJuz;
  final ValueChanged<bool> onChanged;
  const _SegmentedHeader({required this.showJuz, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      decoration: BoxDecoration(border: Border.all(color: AppColors.gold.withOpacity(.55)), borderRadius: BorderRadius.circular(28), color: AppColors.navy2.withOpacity(.7)),
      child: Row(children: [
        Expanded(child: _segment('Surah', !showJuz, () => onChanged(false))),
        Expanded(child: _segment('Juz', showJuz, () => onChanged(true))),
      ]),
    );
  }
  Widget _segment(String label, bool selected, VoidCallback tap) => GestureDetector(onTap: tap, child: AnimatedContainer(duration: const Duration(milliseconds: 180), alignment: Alignment.center, decoration: BoxDecoration(color: selected ? AppColors.goldBright : Colors.transparent, borderRadius: BorderRadius.circular(25)), child: Text(label, style: TextStyle(color: selected ? AppColors.navyDeep : AppColors.cream, fontWeight: FontWeight.w600))));
}

class _QuranTile extends StatelessWidget {
  final int number; final String arabic; final String title; final String subtitle; final VoidCallback onTap;
  const _QuranTile({required this.number, required this.arabic, required this.title, required this.subtitle, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Material(color: Colors.transparent, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(14), child: Container(
      padding: const EdgeInsets.fromLTRB(7, 8, 7, 9),
      decoration: BoxDecoration(color: AppColors.navy2.withOpacity(.92), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.gold.withOpacity(.55), width: 1.05), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 7, offset: const Offset(0, 3))]),
      child: Column(children: [
        Align(alignment: Alignment.topLeft, child: Container(width: 24, height: 24, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.gold.withOpacity(.7))), child: Text('$number', style: const TextStyle(color: AppColors.goldBright, fontSize: 10)))),
        const Spacer(),
        Text(arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.amiri(fontSize: 22, height: 1.2, color: AppColors.goldBright, fontWeight: FontWeight.w700)),
        const SizedBox(height: 7),
        Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cormorantGaramond(fontSize: 16, color: AppColors.cream, fontWeight: FontWeight.w600)),
        const SizedBox(height: 3),
        Text(subtitle, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 8.5, color: AppColors.muted)),
        const Spacer(),
      ]),
    )));
  }
}
