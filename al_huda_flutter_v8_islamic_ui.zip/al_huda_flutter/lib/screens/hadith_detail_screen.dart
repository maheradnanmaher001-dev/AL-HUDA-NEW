import 'package:flutter/material.dart';
import '../services/hadith_service.dart';
import '../theme/app_theme.dart';

class HadithDetailScreen extends StatefulWidget {
  final String collectionKey;
  final String collectionName;
  final String number;

  const HadithDetailScreen({
    super.key,
    required this.collectionKey,
    required this.collectionName,
    required this.number,
  });

  @override
  State<HadithDetailScreen> createState() => _HadithDetailScreenState();
}

class _HadithDetailScreenState extends State<HadithDetailScreen> {
  final _service = HadithService();
  HadithDetail? _detail;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final d = await _service.fetchOne(widget.collectionKey, widget.number);
      setState(() => _detail = d);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  Widget _tag(String label, String? value) {
    if (value == null || value.trim().isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(right: 8, bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.emeraldSoft,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '$label: $value',
        style: const TextStyle(fontSize: 11.5, color: AppColors.emerald, fontWeight: FontWeight.w600),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: Text('${widget.collectionName} · Hadith ${widget.number}')),
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ),
                ),
              )
            : _detail == null
                ? const Center(child: CircularProgressIndicator())
                : Container(
                    color: isDark ? AppColors.readingPaperDark : AppColors.readingPaperLight,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Wrap(
                            children: [
                              _tag('Grade', _detail!.grade),
                              _tag('Narrator', _detail!.narrator),
                              _tag('Book', _detail!.book),
                              _tag('Chapter', _detail!.chapter),
                              _tag('Reference', _detail!.reference),
                            ],
                          ),
                          const SizedBox(height: 12),
                          if (_detail!.textArabic.trim().isNotEmpty) ...[
                            Text(
                              _detail!.textArabic,
                              textDirection: TextDirection.rtl,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontSize: 20,
                                height: 1.9,
                                color: isDark ? AppColors.cream : const Color(0xFF16241D),
                              ),
                            ),
                            const Divider(height: 32),
                          ],
                          Text(
                            _detail!.textEnglish,
                            style: TextStyle(
                              fontSize: 15,
                              height: 1.6,
                              color: isDark ? AppColors.cream.withOpacity(0.9) : const Color(0xFF1B1F1D),
                            ),
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Urdu translation for Hadith isn\'t available from the current data source yet.',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontStyle: FontStyle.italic,
                              color: isDark ? AppColors.cream.withOpacity(0.5) : const Color(0xFF9AA39D),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
      ),
    );
  }
}
