import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../theme/app_background.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: Stack(children: [
        Positioned.fill(child: Image.asset('assets/images/bg_mosque.png', fit: BoxFit.cover, alignment: Alignment.topCenter)),
        Positioned.fill(child: Container(color: AppColors.navy.withOpacity(.78))),
        Positioned.fill(child: Opacity(opacity: .10, child: Image.asset('assets/images/mosque_motif.png', fit: BoxFit.cover))),
        SafeArea(child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(22, 18, 22, 8), child: Row(children: [
            Container(width: 42, height: 42, decoration: BoxDecoration(border: Border.all(color: AppColors.gold, width: 1.2), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.menu, color: AppColors.goldBright)),
            const Spacer(),
            Column(children: [Text('Alhuda', style: GoogleFonts.cormorantGaramond(fontSize: 31, color: AppColors.goldBright, fontWeight: FontWeight.w600)), Text('Your Guide to the Quran', style: GoogleFonts.inter(fontSize: 9, color: AppColors.cream))]),
            const Spacer(), const Icon(Icons.notifications_none, color: AppColors.goldBright, size: 28),
          ]))),
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(24, 30, 24, 20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Assalamu Alaikum', style: TextStyle(color: AppColors.cream, fontSize: 15)),
            const SizedBox(height: 8),
            Text('Seek Guidance,\nFind Peace', style: GoogleFonts.cormorantGaramond(fontSize: 37, height: 1.0, color: AppColors.cream, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10), const Text('Quran, Dua’s, Hadith, Islamic\nKnowledge and more, all in one place.', style: TextStyle(color: AppColors.cream, height: 1.55, fontSize: 14)),
          ]))),
          SliverToBoxAdapter(child: _VerseCard()),
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(24, 22, 24, 12), child: Text('Explore', style: GoogleFonts.cormorantGaramond(fontSize: 23, color: AppColors.cream, fontWeight: FontWeight.w600)))),
          SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 22), sliver: SliverGrid(delegate: SliverChildListDelegate([
            _ExploreTile(Icons.menu_book, 'Quran', 'Read & Listen'), _ExploreTile(Icons.volunteer_activism, 'Duas', 'Daily Supplications'), _ExploreTile(Icons.mosque, 'Hadith', 'Sayings of Prophet'), _ExploreTile(Icons.grain, 'Tasbih', 'Digital Tasbih'), _ExploreTile(Icons.explore, 'Qibla', 'Direction Finder'), _ExploreTile(Icons.article_outlined, 'Islamic', 'Read Articles'), _ExploreTile(Icons.bookmark, 'Bookmarks', 'Saved Verses'), _ExploreTile(Icons.auto_awesome, '99 Names', 'Asma ul Husna'),
          ]), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .82))),
          SliverToBoxAdapter(child: Container(margin: const EdgeInsets.fromLTRB(22, 20, 22, 28), padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: AppColors.navy2.withOpacity(.88), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.gold.withOpacity(.55))), child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Daily Reminder', style: GoogleFonts.cormorantGaramond(fontSize: 21, color: AppColors.goldBright, fontWeight: FontWeight.w600)), const SizedBox(height: 7), const Text('“Indeed, with hardship\ncomes ease.”', style: TextStyle(color: AppColors.cream, height: 1.5)), const SizedBox(height: 5), const Text('(Quran 94:6)', style: TextStyle(color: AppColors.muted, fontSize: 11))])), const Icon(Icons.light, color: AppColors.goldBright, size: 70),
          ]))),
        ])),
      ]),
    );
  }
}

class _VerseCard extends StatelessWidget {
  @override Widget build(BuildContext context) => Container(margin: const EdgeInsets.symmetric(horizontal: 22), padding: const EdgeInsets.fromLTRB(18, 16, 18, 18), decoration: BoxDecoration(color: AppColors.navy2.withOpacity(.84), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.gold.withOpacity(.5))), child: Column(children: [Row(children: [const Icon(Icons.wb_sunny_outlined, color: AppColors.goldBright), const SizedBox(width: 8), const Text('Today’s Verse', style: TextStyle(color: AppColors.cream, fontWeight: FontWeight.w600)), const Spacer(), const Icon(Icons.bookmark_border, color: AppColors.goldBright)]), const SizedBox(height: 14), Text('وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: GoogleFonts.amiri(fontSize: 24, color: AppColors.goldBright)), const SizedBox(height: 8), const Text('“And whoever relies upon Allah –\nthen He is sufficient for him.”', textAlign: TextAlign.center, style: TextStyle(color: AppColors.cream, height: 1.4)), const SizedBox(height: 6), const Text('(Quran 65:3)', style: TextStyle(color: AppColors.muted, fontSize: 11))]));
}

class _ExploreTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle; const _ExploreTile(this.icon, this.title, this.subtitle);
  @override Widget build(BuildContext context) => Container(decoration: BoxDecoration(color: AppColors.navy2.withOpacity(.82), borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.gold.withOpacity(.45))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: AppColors.goldBright, size: 28), const SizedBox(height: 6), Text(title, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.cream, fontSize: 11, fontWeight: FontWeight.w600)), Text(subtitle, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 7.5))]));
}
