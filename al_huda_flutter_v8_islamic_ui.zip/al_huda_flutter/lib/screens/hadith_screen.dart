import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/hadith_service.dart';
import '../theme/app_theme.dart';
import 'hadith_book_screen.dart';
import 'hadith_detail_screen.dart';

class HadithScreen extends StatefulWidget {
  const HadithScreen({super.key});

  @override
  State<HadithScreen> createState() => _HadithScreenState();
}

class _HadithScreenState extends State<HadithScreen> {
  final _service = HadithService();
  List<HadithCollection>? _collections;
  String? _error;

  String _query = '';
  Timer? _debounce;
  List<HadithSummary>? _searchResults;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchCollections();
      setState(() => _collections = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _onSearchChanged(String value) {
    setState(() => _query = value);
    _debounce?.cancel();
    if (value.trim().length < 3) {
      setState(() => _searchResults = null);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      setState(() => _searching = true);
      try {
        final results = await _service.search(value.trim());
        if (mounted) setState(() => _searchResults = results);
      } catch (_) {
        if (mounted) setState(() => _searchResults = []);
      } finally {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  String _collectionName(String key) {
    final match = _collections?.where((c) => c.key == key);
    if (match != null && match.isNotEmpty) return match.first.name;
    return key;
  }

  @override
  Widget build(BuildContext context) {
    final showingSearch = _query.trim().length >= 3;
    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        title: Text('Hadith', style: GoogleFonts.cormorantGaramond(fontSize: 25, fontWeight: FontWeight.w600)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(62),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
            child: Container(
              height: 48,
              decoration: BoxDecoration(color: AppColors.navy2, borderRadius: BorderRadius.circular(25), border: Border.all(color: AppColors.gold.withOpacity(.45))),
              child: TextField(
                onChanged: _onSearchChanged,
                style: const TextStyle(color: AppColors.cream),
                decoration: InputDecoration(
                  hintText: 'Search all Hadith…', hintStyle: const TextStyle(color: AppColors.muted),
                  prefixIcon: const Icon(Icons.search, color: AppColors.gold), suffixIcon: _searching ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))) : null,
                  border: InputBorder.none, contentPadding: const EdgeInsets.symmetric(vertical: 13),
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(child: showingSearch ? _buildSearchResults() : _buildCollections()),
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults == null) return const Center(child: CircularProgressIndicator());
    if (_searchResults!.isEmpty) return const Center(child: Text('No results found.'));
    return ListView.separated(
      padding: const EdgeInsets.all(14), itemCount: _searchResults!.length,
      separatorBuilder: (_, __) => Divider(color: AppColors.gold.withOpacity(.12)),
      itemBuilder: (context, i) { final h = _searchResults![i]; return ListTile(
        leading: const Icon(Icons.menu_book_outlined, color: AppColors.gold),
        title: Text(h.textEnglish, maxLines: 2, overflow: TextOverflow.ellipsis),
        subtitle: Text('${_collectionName(h.collectionKey)} · Hadith ${h.number}'),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => HadithDetailScreen(collectionKey: h.collectionKey, collectionName: _collectionName(h.collectionKey), number: h.number))),
      ); },
    );
  }

  Widget _buildCollections() {
    if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text(_error!, textAlign: TextAlign.center), const SizedBox(height: 12), ElevatedButton(onPressed: _load, child: const Text('Retry'))]));
    if (_collections == null) return const Center(child: CircularProgressIndicator());
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(14, 16, 14, 20),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .9),
      itemCount: _collections!.length,
      itemBuilder: (context, i) { final c = _collections![i]; return _HadithCollectionCard(collection: c, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => HadithBookScreen(collectionKey: c.key, collectionName: c.name)))); },
    );
  }
}

class _HadithCollectionCard extends StatelessWidget {
  final HadithCollection collection; final VoidCallback onTap;
  const _HadithCollectionCard({required this.collection, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return Material(color: Colors.transparent, child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Container(
      decoration: BoxDecoration(gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColors.navy2, AppColors.navyDeep]), borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.gold.withOpacity(.68), width: 1.1)),
      padding: const EdgeInsets.all(10),
      child: Stack(children: [
        const _CornerOrnament(alignment: Alignment.topLeft), const _CornerOrnament(alignment: Alignment.topRight), const _CornerOrnament(alignment: Alignment.bottomLeft), const _CornerOrnament(alignment: Alignment.bottomRight),
        Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (collection.arabicName != null) Text(collection.arabicName!, textAlign: TextAlign.center, textDirection: TextDirection.rtl, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.amiri(fontSize: 22, height: 1.35, color: AppColors.goldBright, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Text(collection.name, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: GoogleFonts.cormorantGaramond(fontSize: 17, color: AppColors.cream, fontWeight: FontWeight.w600)),
          if (collection.count != null) ...[const SizedBox(height: 5), Text('${collection.count} Hadith', style: const TextStyle(color: AppColors.muted, fontSize: 10))],
        ])),
      ]),
    )));
  }
}

class _CornerOrnament extends StatelessWidget {
  final Alignment alignment; const _CornerOrnament({required this.alignment});
  @override Widget build(BuildContext context) { double angle = 0; if (alignment == Alignment.topRight) angle = 1.5708; if (alignment == Alignment.bottomRight) angle = 3.14159; if (alignment == Alignment.bottomLeft) angle = -1.5708; return Align(alignment: alignment, child: Transform.rotate(angle: angle, child: CustomPaint(size: const Size(22,22), painter: _CornerPainter()))); }
}
class _CornerPainter extends CustomPainter {
  @override void paint(Canvas canvas, Size size) { final p=Paint()..color=AppColors.gold.withOpacity(.48)..style=PaintingStyle.stroke..strokeWidth=1.2; final path=Path()..moveTo(0,size.height*.55)..lineTo(0,0)..lineTo(size.width*.55,0); canvas.drawPath(path,p); canvas.drawCircle(Offset(size.width*.2,size.height*.2),1.7,p..style=PaintingStyle.fill); }
  @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
