import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Premium Al-Huda palette: midnight navy, antique gold and warm ivory.
class AppColors {
  static const navy = Color(0xFF081228);
  static const navy2 = Color(0xFF111830);
  static const navyDeep = Color(0xFF040B1D);
  static const gold = Color(0xFFDFB07B);
  static const goldBright = Color(0xFFF0D9A8);
  static const goldSoft = Color(0xFFE6C88F);
  static const cream = Color(0xFFF0E9DE);
  static const creamPaper = Color(0xFFFFFCF5);
  static const charcoal = Color(0xFF070D1C);
  static const darkSurface = Color(0xFF10172C);
  static const muted = Color(0xFFB7B0A7);
  static const readingPaperLight = Color(0xFFFFFCF5);
  static const readingPaperDark = Color(0xFF10172C);

  // Backwards-compatible aliases used by existing screens.
  static const emerald = navy;
  static const emeraldDeep = navyDeep;
  static const emeraldSoft = cream;
}

enum AppTextScale { small, medium, large }

extension AppTextScaleValue on AppTextScale {
  double get factor {
    switch (this) {
      case AppTextScale.small:
        return 0.9;
      case AppTextScale.medium:
        return 1.0;
      case AppTextScale.large:
        return 1.2;
    }
  }
}

class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.gold,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.navy,
      onPrimary: Colors.white,
      secondary: AppColors.gold,
      onSecondary: AppColors.navy,
      surface: AppColors.creamPaper,
      onSurface: const Color(0xFF171B27),
      outline: AppColors.gold.withOpacity(0.45),
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = GoogleFonts.interTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.creamPaper,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(fontFamily: 'serif', fontSize: 22, color: AppColors.cream),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.navyDeep,
        selectedItemColor: AppColors.goldBright,
        unselectedItemColor: Color(0xFF9CA3AF),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navyDeep,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.gold,
      brightness: Brightness.dark,
    ).copyWith(
      primary: AppColors.goldBright,
      onPrimary: AppColors.navyDeep,
      secondary: AppColors.gold,
      surface: AppColors.navy2,
      onSurface: AppColors.cream,
      outline: AppColors.gold.withOpacity(0.5),
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: AppColors.cream,
      displayColor: AppColors.cream,
    );
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.navy,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.navyDeep,
        selectedItemColor: AppColors.goldBright,
        unselectedItemColor: Color(0xFF8E96A6),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navyDeep,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }
}
