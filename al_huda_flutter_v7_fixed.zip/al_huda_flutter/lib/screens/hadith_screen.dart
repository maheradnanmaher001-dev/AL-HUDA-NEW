import 'dart:async';
import 'package:flutter/material.dart';
import '../services/hadith_service.dart';
import '../theme/app_theme.dart';
import 'hadith_book_screen.dart';
import 'hadith_detail_screen.dart';

class HadithScreen extends StatefulWidget {
  const HadithScreen({super.key});

  @override
  State<HadithScreen> createState() => _HadithScreenState();
}

class _HadithScreenState extends State<HadithScreen> {
  final _service = HadithService();
  List<HadithCollection>? _collections;
  String? _error;

  String _query = '';
  Timer? _debounce;
  List<HadithSummary>? _searchResults;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchCollections();
      setState(() => _collections = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _onSearchChanged(String value) {
    setState(() => _query = value);
    _debounce?.cancel();
    if (value.trim().length < 3) {
      setState(() => _searchResults = null);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      setState(() => _searching = true);
      try {
        final results = await _service.search(value.trim());
        if (mounted) setState(() => _searchResults = results);
      } catch (_) {
        if (mounted) setState(() => _searchResults = []);
      } finally {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  String _collectionName(String key) {
    final match = _collections?.where((c) => c.key == key);
    if (match != null && match.isNotEmpty) return match.first.name;
    return key;
  }

  @override
  Widget build(BuildContext context) {
    final showingSearch = _query.trim().length >= 3;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hadith'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Search all Hadith…',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searching
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(child: showingSearch ? _buildSearchResults() : _buildCollections()),
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_searchResults!.isEmpty) {
      return const Center(child: Text('No results found.'));
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _searchResults!.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final h = _searchResults![i];
        return ListTile(
          leading: const Icon(Icons.menu_book_outlined, color: AppColors.emerald),
          title: Text(h.textEnglish, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('${_collectionName(h.collectionKey)} · Hadith ${h.number}'),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => HadithDetailScreen(
              collectionKey: h.collectionKey,
              collectionName: _collectionName(h.collectionKey),
              number: h.number,
            ),
          )),
        );
      },
    );
  }

  Widget _buildCollections() {
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _load, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }
    if (_collections == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return GridView.builder(
      padding: const EdgeInsets.all(14),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
        childAspectRatio: 0.92,
      ),
      itemCount: _collections!.length,
      itemBuilder: (context, i) {
        final c = _collections![i];
        return _HadithCollectionCard(
          collection: c,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => HadithBookScreen(collectionKey: c.key, collectionName: c.name),
          )),
        );
      },
    );
  }
}

/// A decorative book card matching the reference design: a dark emerald
/// plate with ornamental corner marks, the collection's Arabic
/// calligraphic name front and center, and its English name + hadith
/// count underneath.
class _HadithCollectionCard extends StatelessWidget {
  final HadithCollection collection;
  final VoidCallback onTap;

  const _HadithCollectionCard({required this.collection, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [AppColors.darkSurface, AppColors.emeraldDeep],
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.emeraldSoft.withOpacity(0.25)),
          ),
          padding: const EdgeInsets.all(12),
          child: Stack(
            children: [
              const _CornerOrnament(alignment: Alignment.topLeft),
              const _CornerOrnament(alignment: Alignment.topRight),
              const _CornerOrnament(alignment: Alignment.bottomLeft),
              const _CornerOrnament(alignment: Alignment.bottomRight),
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (collection.arabicName != null) ...[
                      Text(
                        collection.arabicName!,
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.rtl,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: AppColors.cream,
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          height: 1.3,
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],
                    Text(
                      collection.name,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppColors.cream,
                        fontSize: 13.5,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (collection.count != null) ...[
                      const SizedBox(height: 6),
                      Text(
                        '${collection.count} Hadith',
                        style: TextStyle(
                          color: AppColors.cream.withOpacity(0.55),
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CornerOrnament extends StatelessWidget {
  final Alignment alignment;
  const _CornerOrnament({required this.alignment});

  @override
  Widget build(BuildContext context) {
    // Rotate a simple corner-bracket icon to match whichever corner
    // this instance sits in.
    double angle = 0;
    if (alignment == Alignment.topRight) angle = 1.5708; // 90°
    if (alignment == Alignment.bottomRight) angle = 3.14159; // 180°
    if (alignment == Alignment.bottomLeft) angle = -1.5708; // -90°
    return Align(
      alignment: alignment,
      child: Transform.rotate(
        angle: angle,
        child: CustomPaint(
          size: const Size(18, 18),
          painter: _CornerPainter(color: AppColors.emeraldSoft.withOpacity(0.35)),
        ),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final Color color;
  _CornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final path = Path()
      ..moveTo(0, size.height * 0.55)
      ..lineTo(0, 0)
      ..lineTo(size.width * 0.55, 0);
    canvas.drawPath(path, paint);
    canvas.drawCircle(Offset(size.width * 0.18, size.height * 0.18), 1.6, paint..style = PaintingStyle.fill);
  }

  @override
  bool shouldRepaint(covariant _CornerPainter oldDelegate) => oldDelegate.color != color;
}
