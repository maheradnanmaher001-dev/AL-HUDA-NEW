import 'package:flutter/material.dart';
import '../data/juz_names.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';
import '../theme/decor.dart';
import 'quran_reader_screen.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  final _service = QuranService();
  bool _showJuz = false;
  List<SurahInfo>? _surahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchSurahList();
      setState(() => _surahs = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _openSurah(SurahInfo s) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.surah,
        number: s.number,
        title: '${s.number}. ${s.nameEnglish}',
        arabicTitle: s.nameArabic,
        subtitle: s.nameTranslation,
      ),
    ));
  }

  void _openJuz(int number) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.juz,
        number: number,
        title: 'Para $number',
        arabicTitle: kJuzNames[number - 1],
        subtitle: 'Juz $number',
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quran'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Surah')),
                ButtonSegment(value: true, label: Text('Juz')),
              ],
              selected: {_showJuz},
              onSelectionChanged: (s) => setState(() => _showJuz = s.first),
              // This control always sits on the dark navy AppBar header,
              // regardless of the app-wide theme — so it always needs
              // light/gold text rather than the theme's body-appropriate
              // color, which is tuned for the (light) body background.
              style: SegmentedButton.styleFrom(
                foregroundColor: AppColors.goldPale,
                selectedForegroundColor: AppColors.navyDeepest,
                selectedBackgroundColor: AppColors.gold,
                side: const BorderSide(color: AppColors.goldBorder),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
              child: HangingLampsHeader(size: 44),
            ),
            Expanded(child: _buildBody()),
          ],
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_showJuz) {
      return GridView.builder(
        padding: const EdgeInsets.all(14),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 0.85,
        ),
        itemCount: 30,
        itemBuilder: (context, i) {
          final juz = i + 1;
          return _GridCard(
            number: '$juz',
            arabic: kJuzNames[i],
            line1: 'Para $juz',
            line2: 'Juz $juz',
            onTap: () => _openJuz(juz),
          );
        },
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _load, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    if (_surahs == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return GridView.builder(
      padding: const EdgeInsets.all(14),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.85,
      ),
      itemCount: _surahs!.length,
      itemBuilder: (context, i) {
        final s = _surahs![i];
        return _GridCard(
          number: '${s.number}',
          arabic: s.nameArabic,
          line1: s.nameEnglish,
          line2: '${s.ayahCount} Ayahs · ${s.revelationType}',
          onTap: () => _openSurah(s),
        );
      },
    );
  }
}

/// A single Surah/Juz tile matching the reference grid: a small gold
/// star-badge number in the top-left corner, the Arabic name large and
/// centered, and the English name + meta line underneath.
class _GridCard extends StatelessWidget {
  final String number;
  final String arabic;
  final String line1;
  final String line2;
  final VoidCallback onTap;

  const _GridCard({
    required this.number,
    required this.arabic,
    required this.line1,
    required this.line2,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.navyCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: AppColors.goldBorder.withOpacity(0.6)),
          ),
          padding: const EdgeInsets.fromLTRB(8, 10, 8, 10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: Container(
                  width: 26,
                  height: 26,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [AppColors.goldBright, AppColors.gold],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Text(
                    number,
                    style: const TextStyle(
                      color: AppColors.navyDeepest,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
              const Spacer(),
              Text(
                arabic,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppFonts.arabicDecorative(fontSize: 20, color: AppColors.goldBright),
              ),
              const SizedBox(height: 8),
              Text(
                line1,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppFonts.body(fontSize: 12.5, weight: FontWeight.w600, color: AppColors.warmWhite),
              ),
              const SizedBox(height: 2),
              Text(
                line2,
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppFonts.label(fontSize: 10, color: AppColors.mutedCream),
              ),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}
