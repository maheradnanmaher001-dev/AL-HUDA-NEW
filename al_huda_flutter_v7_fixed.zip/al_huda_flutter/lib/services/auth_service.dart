import 'dart:convert';
import 'package:http/http.dart' as http;

/// Central place to configure the backend URL.
/// This is the stable Vercel PRODUCTION domain (verified reachable,
/// returns {"status":"AL-HUDA backend is running"} — not a protected
/// preview URL).
const String kApiBaseUrl = "https://al-huda-new-1.vercel.app";

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class AuthService {
  Uri _u(String path) => Uri.parse('$kApiBaseUrl$path');

  Future<Map<String, dynamic>> _post(String path, Map<String, dynamic> body) async {
    late http.Response res;
    try {
      res = await http
          .post(_u(path),
              headers: {'Content-Type': 'application/json'}, body: jsonEncode(body))
          .timeout(const Duration(seconds: 20));
    } catch (_) {
      throw ApiException('Could not reach the server. Check your internet connection.');
    }
    Map<String, dynamic> data = {};
    try {
      data = jsonDecode(res.body) as Map<String, dynamic>;
    } catch (_) {
      // non-JSON error body, ignore
    }
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return data;
    }
    throw ApiException(data['detail']?.toString() ?? 'Something went wrong (${res.statusCode}).');
  }

  /// Registers a new account and triggers a verification email.
  Future<void> register({
    required String email,
    required String password,
    required String city,
    required String country,
  }) =>
      _post('/auth/register', {
        'email': email,
        'password': password,
        'city': city,
        'country': country,
      });

  /// Confirms the 6-digit code sent to the user's email.
  Future<void> verify({required String email, required String code}) =>
      _post('/auth/verify', {'email': email, 'code': code});

  /// Logs in and returns the session token plus the account's saved location.
  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    final data = await _post('/auth/login', {'email': email, 'password': password});
    return data;
  }

  /// Sends a password-reset code to the user's email.
  Future<void> forgotPassword({required String email}) =>
      _post('/auth/forgot-password', {'email': email});

  /// Resets the password using the code emailed to the user.
  Future<void> resetPassword({
    required String email,
    required String code,
    required String newPassword,
  }) =>
      _post('/auth/reset-password', {
        'email': email,
        'code': code,
        'new_password': newPassword,
      });
}
