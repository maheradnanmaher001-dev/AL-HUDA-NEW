import 'dart:convert';
import 'package:http/http.dart' as http;

const String _kHadithApiBase = 'https://ummahapi.com/api';

/// Arabic display names for each collection, since UmmahAPI's
/// `/hadith/collections` response only gives an English name. Keyed by
/// collection slug (e.g. "bukhari").
const Map<String, String> kHadithCollectionArabicNames = {
  'bukhari': 'صحيح البخاري',
  'muslim': 'صحيح مسلم',
  'abudawud': 'سنن أبي داود',
  'tirmidhi': 'جامع الترمذي',
  'ibnmajah': 'سنن ابن ماجه',
  'nasai': 'سنن النسائي',
  'malik': 'موطأ مالك',
  'nawawi40': 'الأربعون النووية',
  'qudsi40': 'الأربعون القدسية',
  'waliullah40': 'أربعون شاه ولي الله',
};

/// Strips a "<collection>-" prefix some endpoints put on the id field
/// (e.g. "bukhari-1" -> "1"), so numbering matches the standard
/// international hadith numbering used by the collection itself.
String _cleanNumber(String raw, String collectionKey) {
  var n = raw.trim();
  final prefix = '$collectionKey-';
  if (n.toLowerCase().startsWith(prefix.toLowerCase())) {
    n = n.substring(prefix.length);
  }
  return n;
}

int? _asInt(dynamic v) {
  if (v == null) return null;
  if (v is int) return v;
  return int.tryParse(v.toString());
}

class HadithCollection {
  final String key;
  final String name;
  final String? arabicName;
  final int? count;

  HadithCollection({required this.key, required this.name, this.arabicName, this.count});

  factory HadithCollection.fromJson(String fallbackKey, Map<String, dynamic> j) {
    final key = (j['key'] ?? j['id'] ?? j['slug'] ?? j['collection'] ?? fallbackKey).toString();
    return HadithCollection(
      key: key,
      name: (j['name'] ?? j['title'] ?? j['collection_name'] ?? fallbackKey).toString(),
      arabicName: (j['arabic_name'] ?? j['name_arabic'])?.toString() ?? kHadithCollectionArabicNames[key],
      count: _asInt(j['count'] ?? j['total'] ?? j['hadith_count'] ?? j['hadiths_count'] ?? j['total_hadith']),
    );
  }
}

class HadithSummary {
  final String collectionKey;
  final String number;
  final String textEnglish;
  final String? textArabic;
  final String? book;
  final String? chapter;

  HadithSummary({
    required this.collectionKey,
    required this.number,
    required this.textEnglish,
    this.textArabic,
    this.book,
    this.chapter,
  });

  factory HadithSummary.fromJson(String collectionKey, Map<String, dynamic> j) {
    final rawNumber =
        (j['hadithnumber'] ?? j['hadith_number'] ?? j['number'] ?? j['id'] ?? '').toString();
    return HadithSummary(
      collectionKey: collectionKey,
      number: _cleanNumber(rawNumber, collectionKey),
      textEnglish: (j['english'] ?? j['hadith_english'] ?? j['text_english'] ?? j['text'] ?? '').toString(),
      textArabic: (j['arabic'] ?? j['hadith_arabic'] ?? j['text_arabic'])?.toString(),
      book: (j['book'] ?? j['book_name'])?.toString(),
      chapter: (j['chapter'] ?? j['chapter_title'])?.toString(),
    );
  }
}

class HadithDetail {
  final String collectionKey;
  final String number;
  final String textArabic;
  final String textEnglish;
  final String? narrator;
  final String? grade;
  final String? book;
  final String? chapter;
  final String? reference;

  HadithDetail({
    required this.collectionKey,
    required this.number,
    required this.textArabic,
    required this.textEnglish,
    this.narrator,
    this.grade,
    this.book,
    this.chapter,
    this.reference,
  });

  factory HadithDetail.fromJson(String collectionKey, Map<String, dynamic> j) {
    final rawNumber =
        (j['hadithnumber'] ?? j['hadith_number'] ?? j['number'] ?? j['id'] ?? '').toString();
    return HadithDetail(
      collectionKey: collectionKey,
      number: _cleanNumber(rawNumber, collectionKey),
      textArabic: (j['arabic'] ?? j['hadith_arabic'] ?? j['text_arabic'] ?? '').toString(),
      textEnglish: (j['english'] ?? j['hadith_english'] ?? j['text_english'] ?? j['text'] ?? '').toString(),
      narrator: (j['narrator'] ?? j['rawi'] ?? j['narrated_by'])?.toString(),
      grade: (j['grade'] ?? j['status'] ?? j['authenticity'])?.toString(),
      book: (j['book'] ?? j['book_name'])?.toString(),
      chapter: (j['chapter'] ?? j['chapter_title'])?.toString(),
      reference: (j['reference'] ?? j['ref'] ?? j['collection_name'])?.toString(),
    );
  }
}

/// Digs into a JSON response to find the actual payload. UmmahAPI wraps
/// every response as {"success": true, "data": ...}, and "data" can
/// itself be a Map keyed by collection slug, a Map with a nested list
/// (e.g. {"hadiths": [...]}), or a List directly — this normalizes all
/// three shapes into a plain List<Map> for the callers below.
dynamic _unwrap(dynamic decoded) {
  if (decoded is Map && decoded.containsKey('data')) return decoded['data'];
  return decoded;
}

List<Map<String, dynamic>> _asListOfMaps(dynamic body, List<String> possibleKeys) {
  if (body is List) {
    return body.whereType<Map<String, dynamic>>().toList();
  }
  if (body is Map) {
    for (final k in possibleKeys) {
      final v = body[k];
      if (v is List) return v.whereType<Map<String, dynamic>>().toList();
    }
    // Some endpoints return a Map keyed by collection slug, e.g.
    // {"bukhari": {"name": "...", "count": 7563}, "muslim": {...}}.
    // Detect that shape (every value is itself a Map) and turn it into
    // a list, carrying the key in so fromJson can use it.
    final values = body.values.toList();
    if (values.isNotEmpty && values.every((v) => v is Map)) {
      return body.entries
          .map((e) => {'key': e.key, ...Map<String, dynamic>.from(e.value as Map)})
          .toList();
    }
  }
  return [];
}

class HadithService {
  Future<List<HadithCollection>> fetchCollections() async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/collections'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load Hadith collections. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final rawList = _asListOfMaps(body, ['collections', 'items']);
    final result = <HadithCollection>[];
    for (final item in rawList) {
      final fallbackKey = item['key']?.toString() ?? 'unknown';
      result.add(HadithCollection.fromJson(fallbackKey, item));
    }
    return result;
  }

  Future<List<HadithSummary>> fetchPage(String collectionKey, {int page = 1, int limit = 30}) async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/$collectionKey?page=$page&limit=$limit'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load this collection. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final rawList = _asListOfMaps(body, ['hadiths', 'items', 'results']);
    return rawList.map((j) => HadithSummary.fromJson(collectionKey, j)).toList();
  }

  Future<HadithDetail> fetchOne(String collectionKey, String number) async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/$collectionKey/$number'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load this Hadith. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    if (body is! Map<String, dynamic>) {
      throw 'Unexpected response while loading this Hadith.';
    }
    return HadithDetail.fromJson(collectionKey, body);
  }

  Future<List<HadithSummary>> search(String query, {String? collectionKey, int limit = 30}) async {
    final params = {
      'q': query,
      'limit': '$limit',
      if (collectionKey != null) 'collection': collectionKey,
    };
    final uri = Uri.parse('$_kHadithApiBase/hadith/search').replace(queryParameters: params);
    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Search failed. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final rawList = _asListOfMaps(body, ['results', 'hadiths', 'items']);
    return rawList
        .map((j) => HadithSummary.fromJson((j['collection'] ?? collectionKey ?? '').toString(), j))
        .toList();
  }
}
