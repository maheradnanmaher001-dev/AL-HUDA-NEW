import 'package:flutter/material.dart';
import 'app_theme.dart';

/// A card wrapped in the ornate gold corner-frame from the reference
/// design. The frame image is 9-slice stretched (via [Image.centerSlice])
/// so the floral corners stay crisp at any card size while the plain
/// border segments stretch to fit.
class OrnateCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final Color? background;
  final VoidCallback? onTap;

  const OrnateCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.background,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final content = Container(
      decoration: BoxDecoration(
        color: background ?? AppColors.navyCard,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/ornate_frame.png',
              fit: BoxFit.fill,
              centerSlice: const Rect.fromLTRB(426, 378, 905, 804),
            ),
          ),
          Padding(padding: padding, child: child),
        ],
      ),
    );
    if (onTap == null) return content;
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(borderRadius: BorderRadius.circular(14), onTap: onTap, child: content),
    );
  }
}

/// The scalloped gold-and-navy nameplate banner used for section titles
/// (e.g. a Surah's name at the top of the reader).
class NameplateBanner extends StatelessWidget {
  final Widget child;
  final double height;

  const NameplateBanner({super.key, required this.child, this.height = 84});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/images/nameplate_banner.png',
              fit: BoxFit.fill,
              centerSlice: const Rect.fromLTRB(565, 0, 1607, 724),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48),
            child: child,
          ),
        ],
      ),
    );
  }
}

/// Decorative hanging lamps flanking a screen header, matching the
/// reference Quran screen. Place inside a [Stack] behind the header
/// content, e.g. at the top of a screen body.
class HangingLampsHeader extends StatelessWidget {
  final double size;
  const HangingLampsHeader({super.key, this.size = 56});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Image.asset('assets/images/lamp_left.png', height: size),
        Image.asset('assets/images/lamp_right.png', height: size),
      ],
    );
  }
}
