import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'app_theme.dart';

/// The soft "shadow type" mosque background, used consistently behind
/// Home, Login and Register content. Opacity/tint adapts per theme so
/// text on top always stays readable.
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(color: isDark ? AppColors.charcoal : AppColors.cream),
        Positioned.fill(
          child: Opacity(
            opacity: isDark ? 0.10 : 0.55,
            child: Image.asset(
              'assets/images/bg_mosque.png',
              fit: BoxFit.cover,
              alignment: Alignment.topCenter,
              color: isDark ? AppColors.cream : null,
              colorBlendMode: isDark ? BlendMode.srcIn : null,
            ),
          ),
        ),
        child,
      ],
    );
  }
}

/// A small Islamic geometric corner ornament (nested arcs + an 8-point
/// star), drawn with vectors so it always renders crisply and adapts to
/// the current theme color automatically — no image asset needed.
class IslamicCornerPainter extends CustomPainter {
  final Color color;
  final bool mirrored;

  IslamicCornerPainter({required this.color, this.mirrored = false});

  @override
  void paint(Canvas canvas, Size size) {
    if (mirrored) {
      canvas.save();
      canvas.translate(size.width, 0);
      canvas.scale(-1, 1);
    }

    final stroke = Paint()
      ..color = color.withOpacity(0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final fillDot = Paint()..color = color.withOpacity(0.5);

    // Nested quarter-arcs radiating from the corner.
    for (final r in [18.0, 32.0, 46.0]) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset.zero, radius: r),
        0,
        1.5708, // 90deg
        false,
        stroke,
      );
    }

    // A small 8-point star motif offset from the corner.
    final center = const Offset(30, 30);
    final path = Path();
    for (int i = 0; i < 8; i++) {
      final angle = (i * 45.0) * math.pi / 180;
      final r = i.isEven ? 9.0 : 4.0;
      final p = Offset(center.dx + r * math.cos(angle), center.dy + r * math.sin(angle));
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, fillDot);

    // Corner accent lines.
    canvas.drawLine(const Offset(0, 46), const Offset(0, 10), stroke);
    canvas.drawLine(const Offset(46, 0), const Offset(10, 0), stroke);

    if (mirrored) canvas.restore();
  }

  @override
  bool shouldRepaint(covariant IslamicCornerPainter oldDelegate) =>
      oldDelegate.color != color || oldDelegate.mirrored != mirrored;
}
