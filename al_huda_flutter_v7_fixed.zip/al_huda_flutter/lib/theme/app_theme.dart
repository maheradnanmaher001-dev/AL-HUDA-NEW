import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// AL-HUDA color palette — deep navy + antique gold, per the reference
/// design. `AppColors.gold`/`emerald` names are kept (rather than
/// renamed) so every screen that already reads `AppColors.gold` for its
/// accent picks up the new palette automatically.
class AppColors {
  // Backgrounds
  static const navy = Color(0xFF081228); // main background
  static const navyCard = Color(0xFF111830); // secondary navy / card
  static const navyDeepest = Color(0xFF040B1D); // darkest areas

  // Gold accents
  static const gold = Color(0xFFDFB07B); // main antique gold
  static const goldBright = Color(0xFFF0D9A8); // soft champagne
  static const goldPale = Color(0xFFE6C88F); // light gold
  static const goldBorder = Color(0xFF8D6F5F); // border gold/bronze
  static const bronze = Color(0xFF6B5654); // dark gold accent

  // Text
  static const warmWhite = Color(0xFFF0E9DE); // main text
  static const mutedCream = Color(0xFFC8BFB2); // secondary text

  // Legacy aliases kept so existing screens (emerald/cream/darkSurface
  // references) keep compiling and pick up the new palette.
  static const emerald = gold;
  static const emeraldDeep = bronze;
  static const emeraldSoft = Color(0x33DFB07B); // translucent gold tint
  static const cream = warmWhite;
  static const charcoal = navy;
  static const darkSurface = navyCard;
  static const readingPaperLight = Color(0xFFFBF3E3);
  static const readingPaperDark = navyCard;
}

/// Font roles used across the app. Headings use Cormorant Garamond,
/// body/UI text uses Inter, and Arabic script (Quran/Hadith text) uses
/// Amiri — all pulled in dynamically via google_fonts, so no font files
/// need to be bundled.
class AppFonts {
  static TextStyle heading({double fontSize = 22, FontWeight weight = FontWeight.w600, Color? color}) =>
      GoogleFonts.cormorantGaramond(fontSize: fontSize, fontWeight: weight, color: color);

  static TextStyle body({double fontSize = 14, FontWeight weight = FontWeight.w400, Color? color}) =>
      GoogleFonts.inter(fontSize: fontSize, fontWeight: weight, color: color);

  static TextStyle label({double fontSize = 12, FontWeight weight = FontWeight.w500, Color? color}) =>
      GoogleFonts.inter(fontSize: fontSize, fontWeight: weight, color: color);

  /// For Quran ayahs, Hadith Arabic text, and any Arabic script content.
  static TextStyle arabic({double fontSize = 20, FontWeight weight = FontWeight.w500, Color? color, double? height}) =>
      GoogleFonts.amiri(fontSize: fontSize, fontWeight: weight, color: color, height: height);

  /// For decorative Arabic headings (e.g. Surah name in its nameplate).
  static TextStyle arabicDecorative({double fontSize = 26, Color? color}) =>
      GoogleFonts.arefRuqaa(fontSize: fontSize, fontWeight: FontWeight.w700, color: color);
}

enum AppTextScale { small, medium, large }

extension AppTextScaleValue on AppTextScale {
  double get factor {
    switch (this) {
      case AppTextScale.small:
        return 0.9;
      case AppTextScale.medium:
        return 1.0;
      case AppTextScale.large:
        return 1.2;
    }
  }
}

class AppTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.gold,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.bronze,
      onPrimary: Colors.white,
      secondary: AppColors.gold,
      surface: AppColors.warmWhite,
      onSurface: AppColors.navyDeepest,
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = _buildTextTheme(base.textTheme, bodyColor: AppColors.navyDeepest);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.warmWhite,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: AppColors.goldBright,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: AppFonts.heading(fontSize: 20, weight: FontWeight.w600, color: AppColors.goldBright),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.navy,
        selectedItemColor: AppColors.gold,
        unselectedItemColor: Color(0xFF7A7466),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navyDeepest,
          padding: const EdgeInsets.symmetric(vertical: 14),
          textStyle: AppFonts.label(fontSize: 15, weight: FontWeight.w600),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: AppColors.goldBorder, width: 1),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.goldBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.goldBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.gold, width: 1.6),
        ),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: AppColors.goldBorder, width: 1),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.gold : Colors.white),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.goldPale : const Color(0xFFE0D6C4)),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.gold,
          selectedForegroundColor: AppColors.navyDeepest,
          foregroundColor: AppColors.bronze,
        ),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.gold,
      brightness: Brightness.dark,
    ).copyWith(
      primary: AppColors.gold,
      onPrimary: AppColors.navyDeepest,
      secondary: AppColors.goldBright,
      surface: AppColors.navyCard,
      onSurface: AppColors.warmWhite,
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = _buildTextTheme(base.textTheme, bodyColor: AppColors.warmWhite);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.navy,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.navy,
        foregroundColor: AppColors.goldBright,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: AppFonts.heading(fontSize: 20, weight: FontWeight.w600, color: AppColors.goldBright),
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.navyDeepest,
        selectedItemColor: AppColors.gold,
        unselectedItemColor: Color(0xFF6C7284),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.gold,
          foregroundColor: AppColors.navyDeepest,
          padding: const EdgeInsets.symmetric(vertical: 14),
          textStyle: AppFonts.label(fontSize: 15, weight: FontWeight.w600),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: AppColors.goldBorder, width: 1),
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.navyCard,
        hintStyle: AppFonts.body(color: AppColors.mutedCream.withOpacity(0.6)),
        labelStyle: AppFonts.body(color: AppColors.mutedCream),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.goldBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.goldBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.gold, width: 1.6),
        ),
      ),
      cardTheme: CardThemeData(
        color: AppColors.navyCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: AppColors.goldBorder, width: 1),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.gold : const Color(0xFF4A4B58)),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.bronze : const Color(0xFF20263A)),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.gold,
          selectedForegroundColor: AppColors.navyDeepest,
          foregroundColor: AppColors.goldPale,
        ),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: AppColors.navyCard,
        surfaceTintColor: Colors.transparent,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static TextTheme _buildTextTheme(TextTheme base, {required Color bodyColor}) {
    final headings = GoogleFonts.cormorantGaramondTextTheme(base).apply(
      bodyColor: bodyColor,
      displayColor: bodyColor,
    );
    final body = GoogleFonts.interTextTheme(base).apply(
      bodyColor: bodyColor,
      displayColor: bodyColor,
    );
    // Cormorant Garamond for display/headline/title roles (headings),
    // Inter for body/label roles (UI + reading text) — matches the
    // "Main headings: Cormorant Garamond / Body text: Inter" spec.
    return body.copyWith(
      displayLarge: headings.displayLarge,
      displayMedium: headings.displayMedium,
      displaySmall: headings.displaySmall,
      headlineLarge: headings.headlineLarge,
      headlineMedium: headings.headlineMedium,
      headlineSmall: headings.headlineSmall,
      titleLarge: headings.titleLarge,
      titleMedium: headings.titleMedium,
    );
  }
}
