import 'package:flutter/material.dart';
import '../data/juz_names.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';
import 'quran_reader_screen.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({super.key});

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  final _service = QuranService();
  bool _showJuz = false;
  List<SurahInfo>? _surahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchSurahList();
      setState(() => _surahs = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _openSurah(SurahInfo s) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.surah,
        number: s.number,
        title: '${s.number}. ${s.nameEnglish}',
      ),
    ));
  }

  void _openJuz(int number) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => QuranReaderScreen(
        mode: ReaderMode.juz,
        number: number,
        title: 'Para $number · ${kJuzNames[number - 1]}',
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quran'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(52),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Surah')),
                ButtonSegment(value: true, label: Text('Juz')),
              ],
              selected: {_showJuz},
              onSelectionChanged: (s) => setState(() => _showJuz = s.first),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: [
            // Faint mosque watermark behind the list for an Islamic touch,
            // matching the Home screen treatment.
            Positioned(
              top: -20,
              left: -40,
              right: -40,
              child: Opacity(
                opacity: 0.06,
                child: Image.asset(
                  'assets/images/mosque_motif.png',
                  fit: BoxFit.fitWidth,
                  color: AppColors.emerald,
                  colorBlendMode: BlendMode.srcIn,
                ),
              ),
            ),
            _buildBody(),
          ],
        ),
      ),
    );
  }

  Widget _numberBadge(String text, bool isDark) {
    return Container(
      width: 38,
      height: 38,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isDark ? AppColors.darkSurface : AppColors.emeraldSoft,
        border: Border.all(
          color: (isDark ? AppColors.cream : AppColors.emerald).withOpacity(0.35),
          width: 1,
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: isDark ? AppColors.cream : AppColors.emerald,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _itemCard({
    required Widget leading,
    required String title,
    required String subtitle,
    required String arabic,
    required VoidCallback onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      elevation: 0,
      color: isDark ? AppColors.darkSurface : Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(
          color: (isDark ? AppColors.cream : AppColors.emerald).withOpacity(0.08),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: leading,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 12)),
        trailing: Text(arabic, style: const TextStyle(fontSize: 18), textDirection: TextDirection.rtl),
        onTap: onTap,
      ),
    );
  }

  Widget _buildBody() {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (_showJuz) {
      return ListView.builder(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: 30,
        itemBuilder: (context, i) {
          final juz = i + 1;
          return _itemCard(
            leading: _numberBadge('$juz', isDark),
            title: 'Para $juz',
            subtitle: 'Juz',
            arabic: kJuzNames[i],
            onTap: () => _openJuz(juz),
          );
        },
      );
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _load, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    if (_surahs == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _surahs!.length,
      itemBuilder: (context, i) {
        final s = _surahs![i];
        return _itemCard(
          leading: _numberBadge('${s.number}', isDark),
          title: s.nameEnglish,
          subtitle: '${s.nameTranslation} · ${s.ayahCount} Ayahs · ${s.revelationType}',
          arabic: s.nameArabic,
          onTap: () => _openSurah(s),
        );
      },
    );
  }
}
