import 'package:flutter/material.dart';
import '../services/quran_service.dart';
import '../theme/app_theme.dart';

enum ReaderMode { surah, juz }

class QuranReaderScreen extends StatefulWidget {
  final ReaderMode mode;
  final int number; // surah number (1-114) or juz number (1-30)
  final String title;

  const QuranReaderScreen({
    super.key,
    required this.mode,
    required this.number,
    required this.title,
  });

  @override
  State<QuranReaderScreen> createState() => _QuranReaderScreenState();
}

class _QuranReaderScreenState extends State<QuranReaderScreen> {
  final _service = QuranService();
  final _scrollController = ScrollController();
  List<Ayah>? _ayahs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
    _scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    if (widget.mode == ReaderMode.surah) {
      _service.saveSurahProgress(widget.number, _scrollController.offset);
    } else {
      _service.saveJuzProgress(widget.number, _scrollController.offset);
    }
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final ayahs = widget.mode == ReaderMode.surah
          ? await _service.fetchSurah(widget.number)
          : await _service.fetchJuz(widget.number);
      setState(() => _ayahs = ayahs);

      // Restore scroll position only if we're re-opening the exact same
      // surah/juz the user last left off on.
      final saved = widget.mode == ReaderMode.surah
          ? await _service.loadSurahProgress()
          : await _service.loadJuzProgress();
      if (saved != null && saved.$1 == widget.number && mounted) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollController.hasClients) {
            _scrollController.jumpTo(saved.$2.clamp(
              0,
              _scrollController.position.maxScrollExtent,
            ));
          }
        });
      }
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: _load, child: const Text('Retry')),
                    ],
                  ),
                ),
              )
            : _ayahs == null
                ? const Center(child: CircularProgressIndicator())
                : Container(
                    color: isDark ? AppColors.readingPaperDark : AppColors.readingPaperLight,
                    child: ListView.separated(
                      controller: _scrollController,
                      padding: const EdgeInsets.all(20),
                      itemCount: _ayahs!.length,
                      separatorBuilder: (_, __) => Divider(
                        height: 32,
                        color: (isDark ? AppColors.cream : AppColors.emerald).withOpacity(0.12),
                      ),
                      itemBuilder: (context, i) {
                        final a = _ayahs![i];
                        final arabicColor = isDark ? AppColors.cream : const Color(0xFF16241D);
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text.rich(
                              TextSpan(
                                style: TextStyle(
                                  fontSize: 22,
                                  height: 2.0,
                                  color: arabicColor,
                                ),
                                children: [
                                  TextSpan(text: '${a.arabic} '),
                                  WidgetSpan(
                                    alignment: PlaceholderAlignment.middle,
                                    child: Container(
                                      width: 26,
                                      height: 26,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(
                                          color: AppColors.emerald.withOpacity(isDark ? 0.6 : 0.5),
                                          width: 1.2,
                                        ),
                                      ),
                                      child: Text(
                                        '${a.numberInSurah}',
                                        style: TextStyle(
                                          fontSize: 10,
                                          color: isDark ? AppColors.cream : AppColors.emerald,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              textDirection: TextDirection.rtl,
                              textAlign: TextAlign.right,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              a.urdu,
                              textDirection: TextDirection.rtl,
                              textAlign: TextAlign.right,
                              style: TextStyle(
                                fontSize: 15,
                                height: 1.7,
                                color: isDark ? AppColors.cream.withOpacity(0.85) : const Color(0xFF3A453E),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              a.english,
                              style: TextStyle(
                                fontSize: 13,
                                color: isDark ? AppColors.cream.withOpacity(0.65) : const Color(0xFF6B7A70),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}
