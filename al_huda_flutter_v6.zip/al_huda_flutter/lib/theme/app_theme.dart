import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// AL-HUDA color palette: matte dark emerald green + cream only (no gold).
class AppColors {
  // Matte dark emerald — flat, slightly desaturated so it doesn't look glossy.
  static const emerald = Color(0xFF0B4732);
  static const emeraldDeep = Color(0xFF073A28);
  static const emeraldSoft = Color(0xFFE7F0EA); // tint used for chip backgrounds
  static const cream = Color(0xFFFBF6EC);
  static const charcoal = Color(0xFF15201B);
  static const darkSurface = Color(0xFF102821);
  // A soft, slightly warm off-white used behind long reading text — easier
  // on the eyes than pure white/cream and reads clearly in both themes.
  static const readingPaperLight = Color(0xFFFFFCF5);
  static const readingPaperDark = Color(0xFF16302A);
}

enum AppTextScale { small, medium, large }

extension AppTextScaleValue on AppTextScale {
  double get factor {
    switch (this) {
      case AppTextScale.small:
        return 0.9;
      case AppTextScale.medium:
        return 1.0;
      case AppTextScale.large:
        return 1.2;
    }
  }
}

class AppTheme {
  static ThemeData light() {
    // IMPORTANT: build the FULL Material 3 tonal palette from our emerald
    // seed color (not just override 2-3 fields on top of Flutter's default
    // purple scheme) — otherwise components like Switch, SegmentedButton
    // and AlertDialog keep pulling purple from roles we didn't override
    // (primaryContainer, outline, etc.), which is what caused the
    // off-brand purple/blue tint on toggles and dialogs.
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.emerald,
      brightness: Brightness.light,
    ).copyWith(
      primary: AppColors.emerald,
      onPrimary: Colors.white,
      secondary: AppColors.emeraldDeep,
      surface: AppColors.cream,
      onSurface: const Color(0xFF1B1F1D),
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.cream,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.emerald,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.emerald,
        unselectedItemColor: Color(0xFF9AA39D),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.emerald,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.emerald : Colors.white),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.emeraldSoft : const Color(0xFFD8DED9)),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.emerald,
          selectedForegroundColor: Colors.white,
          foregroundColor: AppColors.emerald,
        ),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.emerald,
      brightness: Brightness.dark,
    ).copyWith(
      primary: AppColors.cream,
      onPrimary: AppColors.emeraldDeep,
      secondary: AppColors.emeraldSoft,
      surface: AppColors.darkSurface,
      onSurface: AppColors.cream,
    );
    final base = ThemeData.from(colorScheme: scheme, useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme).apply(
      bodyColor: AppColors.cream,
      displayColor: AppColors.cream,
    );
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.charcoal,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.darkSurface,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.darkSurface,
        selectedItemColor: AppColors.cream,
        unselectedItemColor: Color(0xFF7C8B83),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.emeraldSoft,
          foregroundColor: AppColors.emeraldDeep,
          padding: const EdgeInsets.symmetric(vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.cream : const Color(0xFF5A6B62)),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected) ? AppColors.emerald : const Color(0xFF24352E)),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.emeraldSoft,
          selectedForegroundColor: AppColors.emeraldDeep,
          foregroundColor: AppColors.cream,
        ),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: AppColors.darkSurface,
        surfaceTintColor: Colors.transparent,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }
}
