class HadithBook {
  final String nameEnglish;
  final String nameArabic;
  final String compiler;
  final int approxHadithCount;

  const HadithBook({
    required this.nameEnglish,
    required this.nameArabic,
    required this.compiler,
    required this.approxHadithCount,
  });
}

/// Well-known authentic Hadith collections. Hadith counts are commonly
/// cited approximate figures. The six major ones (Kutub al-Sittah) are
/// listed first, followed by other widely referenced collections.
const List<HadithBook> kHadithBooks = [
  // Kutub al-Sittah (the six major collections)
  HadithBook(nameEnglish: 'Sahih al-Bukhari', nameArabic: 'صحيح البخاري', compiler: 'Imam Muhammad al-Bukhari', approxHadithCount: 7563),
  HadithBook(nameEnglish: 'Sahih Muslim', nameArabic: 'صحيح مسلم', compiler: 'Imam Muslim ibn al-Hajjaj', approxHadithCount: 7500),
  HadithBook(nameEnglish: "Sunan Abu Dawud", nameArabic: 'سنن أبي داود', compiler: 'Imam Abu Dawud', approxHadithCount: 5274),
  HadithBook(nameEnglish: 'Jami at-Tirmidhi', nameArabic: 'جامع الترمذي', compiler: 'Imam at-Tirmidhi', approxHadithCount: 3956),
  HadithBook(nameEnglish: "Sunan an-Nasa'i", nameArabic: 'سنن النسائي', compiler: "Imam an-Nasa'i", approxHadithCount: 5758),
  HadithBook(nameEnglish: 'Sunan Ibn Majah', nameArabic: 'سنن ابن ماجه', compiler: 'Imam Ibn Majah', approxHadithCount: 4341),

  // Other widely referenced collections
  HadithBook(nameEnglish: 'Muwatta Malik', nameArabic: 'موطأ مالك', compiler: 'Imam Malik ibn Anas', approxHadithCount: 1720),
  HadithBook(nameEnglish: 'Musnad Ahmad', nameArabic: 'مسند أحمد', compiler: 'Imam Ahmad ibn Hanbal', approxHadithCount: 26363),
  HadithBook(nameEnglish: 'Sunan ad-Darimi', nameArabic: 'سنن الدارمي', compiler: 'Imam ad-Darimi', approxHadithCount: 3367),
  HadithBook(nameEnglish: 'Riyad as-Salihin', nameArabic: 'رياض الصالحين', compiler: 'Imam an-Nawawi', approxHadithCount: 1896),
  HadithBook(nameEnglish: "Bulugh al-Maram", nameArabic: 'بلوغ المرام', compiler: 'Ibn Hajar al-Asqalani', approxHadithCount: 1358),
  HadithBook(nameEnglish: "Al-Adab Al-Mufrad", nameArabic: 'الأدب المفرد', compiler: 'Imam al-Bukhari', approxHadithCount: 1322),
  HadithBook(nameEnglish: 'Shama\'il Muhammadiyah', nameArabic: 'الشمائل المحمدية', compiler: 'Imam at-Tirmidhi', approxHadithCount: 397),
  HadithBook(nameEnglish: "40 Hadith Nawawi", nameArabic: 'الأربعون النووية', compiler: 'Imam an-Nawawi', approxHadithCount: 42),
  HadithBook(nameEnglish: "40 Hadith Qudsi", nameArabic: 'الأربعون القدسية', compiler: 'Various', approxHadithCount: 40),
];
