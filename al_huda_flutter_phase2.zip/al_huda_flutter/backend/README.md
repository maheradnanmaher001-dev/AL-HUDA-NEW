# AL-HUDA Backend — Deployment Guide

Ye chhota FastAPI server hai jo sirf ek kaam karta hai: account
register/login/verify/reset-password ke email codes bhejta hai
(Brevo ke through) aur user accounts store karta hai.

## Step 1 — Brevo account banayein (email bhejne ke liye)

1. https://www.brevo.com par free account banayein
2. Left menu mein **Senders, Domains & Dedicated IPs** → **Senders** mein
   jayein → apni koi bhi email add karein (jaise aapki Gmail) → Brevo
   us email par ek confirmation link bhejega, usay open kar ke verify
   kar dein
3. Left menu mein **SMTP & API** → **API Keys** → **Generate a new API
   key** → naam kuch bhi de dein (jaise "AL-HUDA") → key copy kar lein
   (ye sirf ek dafa dikhti hai, kahin save kar lein)

## Step 2 — Render par backend deploy karein

1. https://render.com par GitHub account se sign up karein
2. **New +** → **Web Service** → apna GitHub repo select karein
3. Render `backend/render.yaml` khud dhoondh lega aur settings apply
   kar dega. Agar manually karna pade to:
   - **Root Directory**: `backend`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. **Environment** tab mein jaake ye variables add karein
   (`.env.example` file dekhein):
   - `JWT_SECRET` — koi bhi lamba random string
   - `BREVO_API_KEY` — Step 1 wali key
   - `SENDER_EMAIL` — Step 1 mein verify ki hui email
   - `SENDER_NAME` — `AL-HUDA`
5. **Deploy** dabayein. Kuch minute mein ek URL milega, jaise:
   `https://al-huda-backend.onrender.com`

## Step 3 — App ko backend se connect karein

`lib/services/auth_service.dart` file mein ye line dhoondein:

```dart
const String kApiBaseUrl = "https://your-backend-url.example.com";
```

Isay apne asal Render URL se replace kar dein, phir app dobara build
karein.

## Important note — free tier database

Render ka **free** plan har naye deploy par disk reset kar deta hai —
matlab agar aap dobara deploy karein (naya code push karein) to
purane accounts ka data (SQLite database) delete ho sakta hai. Testing
ke liye ye theek hai. Jab app real users ke liye taiyar ho, in mein se
ek karna hoga:

- Render ka **Persistent Disk** add-on use karein (paid, thoda sasta), ya
- Ek free hosted database use karein (jaise **Neon** ya **Supabase** —
  dono free PostgreSQL dete hain) aur `DATABASE_URL` env variable
  usi se point karein

## Testing without email (optional)

Agar `BREVO_API_KEY` set nahi hai, server email bhejne ki koshish
nahi karega — is ki jagah code Render ke **Logs** tab mein print ho
jayega, taake bina email setup ke bhi test kar sakein.
