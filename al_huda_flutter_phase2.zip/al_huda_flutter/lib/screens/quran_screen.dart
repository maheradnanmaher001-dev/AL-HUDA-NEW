import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class QuranScreen extends StatelessWidget {
  const QuranScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Quran')),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.menu_book, size: 56, color: AppColors.emerald),
              const SizedBox(height: 12),
              const Text('Quran by Surah / Juz — coming in Phase 3'),
            ],
          ),
        ),
      ),
    );
  }
}
