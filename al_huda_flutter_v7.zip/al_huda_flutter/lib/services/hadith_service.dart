import 'dart:convert';
import 'package:http/http.dart' as http;

const String _kHadithApiBase = 'https://ummahapi.com/api';

class HadithCollection {
  final String key;
  final String name;
  final int? count;

  HadithCollection({required this.key, required this.name, this.count});

  factory HadithCollection.fromJson(String fallbackKey, Map<String, dynamic> j) {
    return HadithCollection(
      key: (j['key'] ?? j['id'] ?? j['slug'] ?? fallbackKey).toString(),
      name: (j['name'] ?? j['title'] ?? j['collection'] ?? fallbackKey).toString(),
      count: _asInt(j['count'] ?? j['total'] ?? j['hadith_count'] ?? j['hadiths_count']),
    );
  }
}

class HadithSummary {
  final String collectionKey;
  final String number;
  final String textEnglish;
  final String? book;
  final String? chapter;

  HadithSummary({
    required this.collectionKey,
    required this.number,
    required this.textEnglish,
    this.book,
    this.chapter,
  });

  factory HadithSummary.fromJson(String collectionKey, Map<String, dynamic> j) {
    return HadithSummary(
      collectionKey: collectionKey,
      number: (j['hadith_number'] ?? j['number'] ?? j['id'] ?? '').toString(),
      textEnglish: (j['hadith_english'] ?? j['english'] ?? j['text_english'] ?? j['text'] ?? '').toString(),
      book: j['book']?.toString(),
      chapter: (j['chapter'] ?? j['chapter_title'])?.toString(),
    );
  }
}

class HadithDetail {
  final String collectionKey;
  final String number;
  final String textArabic;
  final String textEnglish;
  final String? narrator;
  final String? grade;
  final String? book;
  final String? chapter;
  final String? reference;

  HadithDetail({
    required this.collectionKey,
    required this.number,
    required this.textArabic,
    required this.textEnglish,
    this.narrator,
    this.grade,
    this.book,
    this.chapter,
    this.reference,
  });

  factory HadithDetail.fromJson(String collectionKey, Map<String, dynamic> j) {
    return HadithDetail(
      collectionKey: collectionKey,
      number: (j['hadith_number'] ?? j['number'] ?? j['id'] ?? '').toString(),
      textArabic: (j['hadith_arabic'] ?? j['arabic'] ?? j['text_arabic'] ?? '').toString(),
      textEnglish: (j['hadith_english'] ?? j['english'] ?? j['text_english'] ?? j['text'] ?? '').toString(),
      narrator: (j['narrator'] ?? j['rawi'] ?? j['narrated_by'])?.toString(),
      grade: (j['grade'] ?? j['status'] ?? j['authenticity'])?.toString(),
      book: j['book']?.toString(),
      chapter: (j['chapter'] ?? j['chapter_title'])?.toString(),
      reference: (j['reference'] ?? j['ref'])?.toString(),
    );
  }
}

int? _asInt(dynamic v) {
  if (v == null) return null;
  if (v is int) return v;
  return int.tryParse(v.toString());
}

/// Digs into a JSON response to find the actual payload, since different
/// endpoints on this API wrap results slightly differently (a top-level
/// "data" key, or the list directly).
dynamic _unwrap(dynamic decoded) {
  if (decoded is Map && decoded.containsKey('data')) return decoded['data'];
  return decoded;
}

class HadithService {
  Future<List<HadithCollection>> fetchCollections() async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/collections'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load Hadith collections. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final List rawList = body is List ? body : (body is Map ? (body['collections'] ?? []) : []);
    final result = <HadithCollection>[];
    for (final item in rawList) {
      if (item is Map<String, dynamic>) {
        result.add(HadithCollection.fromJson('unknown', item));
      } else if (item is String) {
        result.add(HadithCollection(key: item, name: item));
      }
    }
    return result;
  }

  Future<List<HadithSummary>> fetchPage(String collectionKey, {int page = 1, int limit = 30}) async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/$collectionKey?page=$page&limit=$limit'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load this collection. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final List rawList = body is List ? body : (body is Map ? (body['hadiths'] ?? body['items'] ?? []) : []);
    return rawList
        .whereType<Map<String, dynamic>>()
        .map((j) => HadithSummary.fromJson(collectionKey, j))
        .toList();
  }

  Future<HadithDetail> fetchOne(String collectionKey, String number) async {
    final res = await http
        .get(Uri.parse('$_kHadithApiBase/hadith/$collectionKey/$number'))
        .timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Could not load this Hadith. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    if (body is! Map<String, dynamic>) {
      throw 'Unexpected response while loading this Hadith.';
    }
    return HadithDetail.fromJson(collectionKey, body);
  }

  Future<List<HadithSummary>> search(String query, {String? collectionKey, int limit = 30}) async {
    final params = {
      'q': query,
      'limit': '$limit',
      if (collectionKey != null) 'collection': collectionKey,
    };
    final uri = Uri.parse('$_kHadithApiBase/hadith/search').replace(queryParameters: params);
    final res = await http.get(uri).timeout(const Duration(seconds: 15));
    if (res.statusCode != 200) {
      throw 'Search failed. Check your internet connection.';
    }
    final body = _unwrap(jsonDecode(res.body));
    final List rawList = body is List ? body : (body is Map ? (body['results'] ?? body['hadiths'] ?? []) : []);
    return rawList
        .whereType<Map<String, dynamic>>()
        .map((j) => HadithSummary.fromJson((j['collection'] ?? collectionKey ?? '').toString(), j))
        .toList();
  }
}
