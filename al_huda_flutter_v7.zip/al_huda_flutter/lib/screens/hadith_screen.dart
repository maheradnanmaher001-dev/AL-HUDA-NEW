import 'dart:async';
import 'package:flutter/material.dart';
import '../services/hadith_service.dart';
import '../theme/app_theme.dart';
import 'hadith_book_screen.dart';
import 'hadith_detail_screen.dart';

class HadithScreen extends StatefulWidget {
  const HadithScreen({super.key});

  @override
  State<HadithScreen> createState() => _HadithScreenState();
}

class _HadithScreenState extends State<HadithScreen> {
  final _service = HadithService();
  List<HadithCollection>? _collections;
  String? _error;

  String _query = '';
  Timer? _debounce;
  List<HadithSummary>? _searchResults;
  bool _searching = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final list = await _service.fetchCollections();
      setState(() => _collections = list);
    } catch (e) {
      setState(() => _error = e.toString());
    }
  }

  void _onSearchChanged(String value) {
    setState(() => _query = value);
    _debounce?.cancel();
    if (value.trim().length < 3) {
      setState(() => _searchResults = null);
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      setState(() => _searching = true);
      try {
        final results = await _service.search(value.trim());
        if (mounted) setState(() => _searchResults = results);
      } catch (_) {
        if (mounted) setState(() => _searchResults = []);
      } finally {
        if (mounted) setState(() => _searching = false);
      }
    });
  }

  String _collectionName(String key) {
    final match = _collections?.where((c) => c.key == key);
    if (match != null && match.isNotEmpty) return match.first.name;
    return key;
  }

  @override
  Widget build(BuildContext context) {
    final showingSearch = _query.trim().length >= 3;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Hadith'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: TextField(
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Search all Hadith…',
                  prefixIcon: const Icon(Icons.search),
                  suffixIcon: _searching
                      ? const Padding(
                          padding: EdgeInsets.all(12),
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        )
                      : null,
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(child: showingSearch ? _buildSearchResults() : _buildCollections()),
    );
  }

  Widget _buildSearchResults() {
    if (_searchResults == null) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_searchResults!.isEmpty) {
      return const Center(child: Text('No results found.'));
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _searchResults!.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final h = _searchResults![i];
        return ListTile(
          leading: const Icon(Icons.menu_book_outlined, color: AppColors.emerald),
          title: Text(h.textEnglish, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('${_collectionName(h.collectionKey)} · #${h.number}'),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => HadithDetailScreen(
              collectionKey: h.collectionKey,
              collectionName: _collectionName(h.collectionKey),
              number: h.number,
            ),
          )),
        );
      },
    );
  }

  Widget _buildCollections() {
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: _load, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }
    if (_collections == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _collections!.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final c = _collections![i];
        return ListTile(
          leading: const CircleAvatar(
            backgroundColor: AppColors.emeraldSoft,
            child: Icon(Icons.menu_book_outlined, color: AppColors.emerald, size: 18),
          ),
          title: Text(c.name),
          subtitle: c.count != null ? Text('${c.count} Hadith') : null,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => HadithBookScreen(collectionKey: c.key, collectionName: c.name),
          )),
        );
      },
    );
  }
}
