import 'package:flutter/material.dart';
import '../services/hadith_service.dart';
import '../theme/app_theme.dart';
import 'hadith_detail_screen.dart';

class HadithBookScreen extends StatefulWidget {
  final String collectionKey;
  final String collectionName;

  const HadithBookScreen({
    super.key,
    required this.collectionKey,
    required this.collectionName,
  });

  @override
  State<HadithBookScreen> createState() => _HadithBookScreenState();
}

class _HadithBookScreenState extends State<HadithBookScreen> {
  final _service = HadithService();
  final _scrollController = ScrollController();
  final List<HadithSummary> _items = [];
  int _page = 1;
  bool _loading = false;
  bool _hasMore = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadMore();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels > _scrollController.position.maxScrollExtent - 300) {
        _loadMore();
      }
    });
  }

  Future<void> _loadMore() async {
    if (_loading || !_hasMore) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final batch = await _service.fetchPage(widget.collectionKey, page: _page, limit: 30);
      setState(() {
        _items.addAll(batch);
        _hasMore = batch.isNotEmpty;
        _page++;
      });
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.collectionName)),
      body: SafeArea(
        child: _items.isEmpty && _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_error!, textAlign: TextAlign.center),
                      const SizedBox(height: 12),
                      ElevatedButton(onPressed: _loadMore, child: const Text('Retry')),
                    ],
                  ),
                ),
              )
            : _items.isEmpty && _loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _items.length + 1,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      if (i == _items.length) {
                        return Padding(
                          padding: const EdgeInsets.all(16),
                          child: Center(
                            child: _loading
                                ? const CircularProgressIndicator()
                                : (!_hasMore ? const Text('End of collection') : const SizedBox.shrink()),
                          ),
                        );
                      }
                      final h = _items[i];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppColors.emeraldSoft,
                          child: Text(h.number, style: const TextStyle(color: AppColors.emerald, fontSize: 11)),
                        ),
                        title: Text(
                          h.textEnglish,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: (h.chapter != null && h.chapter!.isNotEmpty) ? Text(h.chapter!) : null,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => HadithDetailScreen(
                            collectionKey: widget.collectionKey,
                            collectionName: widget.collectionName,
                            number: h.number,
                          ),
                        )),
                      );
                    },
                  ),
      ),
    );
  }
}
