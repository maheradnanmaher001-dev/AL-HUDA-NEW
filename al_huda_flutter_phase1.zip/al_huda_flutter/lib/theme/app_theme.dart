import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// AL-HUDA color palette: Emerald Green + Gold + Cream.
class AppColors {
  static const emerald = Color(0xFF0E6E4E);
  static const emeraldDark = Color(0xFF094E37);
  static const gold = Color(0xFFC9A24B);
  static const cream = Color(0xFFFBF6EC);
  static const charcoal = Color(0xFF1B1F1D);
  static const darkSurface = Color(0xFF13251E);
}

enum AppTextScale { small, medium, large }

extension AppTextScaleValue on AppTextScale {
  double get factor {
    switch (this) {
      case AppTextScale.small:
        return 0.9;
      case AppTextScale.medium:
        return 1.0;
      case AppTextScale.large:
        return 1.2;
    }
  }
}

class AppTheme {
  static ThemeData light() {
    final base = ThemeData.light(useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme);
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.cream,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.emerald,
        secondary: AppColors.gold,
        surface: AppColors.cream,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.emerald,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: Colors.white,
        selectedItemColor: AppColors.emerald,
        unselectedItemColor: Color(0xFF9AA39D),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }

  static ThemeData dark() {
    final base = ThemeData.dark(useMaterial3: true);
    final textTheme = GoogleFonts.notoSansTextTheme(base.textTheme).apply(
      bodyColor: AppColors.cream,
      displayColor: AppColors.cream,
    );
    return base.copyWith(
      scaffoldBackgroundColor: AppColors.charcoal,
      colorScheme: base.colorScheme.copyWith(
        primary: AppColors.gold,
        secondary: AppColors.emerald,
        surface: AppColors.darkSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.darkSurface,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.darkSurface,
        selectedItemColor: AppColors.gold,
        unselectedItemColor: Color(0xFF7C8B83),
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
      textTheme: textTheme,
      useMaterial3: true,
    );
  }
}
